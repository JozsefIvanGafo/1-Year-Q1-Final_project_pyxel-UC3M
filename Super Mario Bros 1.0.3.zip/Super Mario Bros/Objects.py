"""
Super mario bros game
description:
Here the program will create the class objects to create all the objects such as pipes, blocks etc.
@Author: József Iván Gafo and Marcos González
@since 11/14/2021
@Version 0.0.1
"""
import pyxel
from mario import Mario
from enemies import Enemies

class Objects:
    def __init__(self) :
        self.floor=208
        #Here we put variables for the x and y for breakable bricks
        x_normal_brick=[128,160]
        y_normal_brick=[176,176]
        
        self.normal_brick_list = []
        for i in range(len(x_normal_brick)):
            brick=[x_normal_brick[i],y_normal_brick[i]]
            self.normal_brick_list.append(brick)

        #Here we put the x and y for the question bricks
        x_question_brick=[144,144,176]
        y_question_brick=[128,176,208]

        self.question_brick_list = []
        for i in range(len(x_question_brick)):
            question_brick=[x_question_brick[i],y_question_brick[i]]
            self.question_brick_list.append(question_brick)

        #Here we put the x and y for the clouds

        x_cloud=[15,70,120,170,240,300,370,430,500]
        y_cloud=[15,60,2,40,24,55,20,60,34]
        
        self.cloud_list = []
        for i in range(len(x_cloud)):
            cloud=[x_cloud[i],y_cloud[i]]
            self.cloud_list.append(cloud)

        #Here we put the x and y for the bushes

        x_bush=[20,170,330,400,500]
        y_bush=[208,208,208,208,208]
        
        self.bush_list = []
        for i in range(len(x_bush)):
            bush=[x_bush[i],y_bush[i]]
            self.bush_list.append(bush)

        #Here we put the x and y for the pipes
        self.size_pipe=32
        x_pipe=[65,290]
        y_pipe=[192,192]
        
        self.pipe_list = []
        for i in range(len(x_pipe)):
            pipe=[x_pipe[i],y_pipe[i]]
            self.pipe_list.append(pipe)


        #Sprites for every block
        self.sprite_question_brick=(0,16,0,16,16)
        self.sprite_normal_brick=(0,0,16,16,16)
        self.sprite_cloud=(0,16,64,48,24)
        self.sprite_bush=(0,16,88,48,16)
        self.sprite_pipe=(0,32,0,32,32)
        #max length
        max_length=[len(x_bush),len(x_cloud),len(x_normal_brick),len(x_pipe),len(x_question_brick)]
        self.max=max(max_length)

    #we update the coordinates of the objects
    def update_coordinates(self):
        """
        This function will be in charge to update the coordinates of every block, and if a block already passed the x =-32,
        then it will be deleted to free the memory
        """
        """"""
        #We update the coordinates of every object on the game like pipes, bushes. And if i passes the -32 coordinates we delete it to free memory
        for i in range(self.max):
            #Update the coordinates of pipes
            if i<len(self.pipe_list):
                    self.pipe_list[i][0]-=2
                    if self.pipe_list[i][0]<-32:
                        del self.pipe_list[i]
                        print("pipe deleted")
            #Update the coordinates of normal bricks
            if i<len(self.normal_brick_list):
                    self.normal_brick_list[i][0]-=2
                    if self.normal_brick_list[i][0]<-32:
                        del self.normal_brick_list[i]
                        print("normal brick deleted")
            #Update the coordinates of question bricks
            if i<len(self.question_brick_list):
                    self.question_brick_list[i][0]-=2
                    if self.question_brick_list[i][0]<-32:
                        del self.question_brick_list[i]
                        print("question brick deleted")
            #Update the coordinates of clouds
            if i<len(self.cloud_list):
                    self.cloud_list[i][0]-=2
                    if self.cloud_list[i][0]<-32:
                        del self.cloud_list[i]
                        print("cloud deleted")
            #Update the coordinates of bushes
            if i<len(self.bush_list):
                    self.bush_list[i][0]-=2
                    if self.bush_list[i][0]<-32:
                        del self.bush_list[i]
                        print("bush deleted")

        #We recalculate the maximum (so the loops on the program are shorther)
        max_length=[len(self.bush_list),len(self.cloud_list),len(self.normal_brick_list),len(self.pipe_list),len(self.question_brick_list)]
        self.max=max(max_length)

    #colision of the blocks in x
    def x_collision(self,mario:object,x:bool=False,minus_x:bool=False)->bool:
        """
        This function will determine if mario can move on the x axis, if it can move it will return True, else it will return false
        @param other ,we import the data from mario or the enemies (especially its coordinates)
        @param x, if mario is moving to the right
        @param minus_x, if mario is moving to the left
        """
        
        can_movement=True
        #If there is a collision on front
        if x:
            #loop to check if there is and object in front of mario or the ennemy
            for i in range(self.max):
                #If there is a pipe in front
                if i<len(self.pipe_list):
                    if (mario.x) >= (self.pipe_list[i][0]-16)  and mario.y > self.pipe_list[i][1] and mario.x <= (self.pipe_list[i][0]+32):
                        can_movement =False
                #If there is a normal block in front
                if i<len(self.normal_brick_list):   
                    if mario.x >= (self.normal_brick_list[i][0]-12) and mario.x <= (self.normal_brick_list[i][0]) and mario.y >self.normal_brick_list[i][1]-8 and mario.y < self.normal_brick_list[i][1]+3:   #self.normal_brick_list[i][1]: #and other.y<self.normal_brick_list[i][1]-8:
                        can_movement =False
                #If there is a question brick in front
                if i<len(self.question_brick_list):   
                    if mario.x >= (self.question_brick_list[i][0]-12) and mario.x <= (self.question_brick_list[i][0]) and mario.y >= self.question_brick_list[i][1]-8 and mario.y <= self.question_brick_list[i][1]+3:
                        can_movement =False

        #If there is a collision on the back of mario
        if minus_x:
            for i in range(self.max):
                #If there is a pipe behind
                if i<len(self.pipe_list):
                    if mario.x <= (self.pipe_list[i][0]+34) and mario.x >= (self.pipe_list[i][0]-14) and mario.y > self.pipe_list[i][1]:
                        can_movement =False
                #If there is a normal block behind
                if i<len(self.normal_brick_list):   
                    if mario.x <= (self.normal_brick_list[i][0]+16) and mario.x >= (self.normal_brick_list[i][0]) and mario.y > self.normal_brick_list[i][1]-8 and mario.y < self.normal_brick_list[i][1]+3:
                        can_movement =False
                #IF there is a question brick behind
                if i<len(self.question_brick_list):   
                    if mario.x <= (self.question_brick_list[i][0]+16) and mario.x >= (self.question_brick_list[i][0]) and mario.y >= self.question_brick_list[i][1]-8 and mario.y <= self.question_brick_list[i][1]+3:
                        can_movement =False
        #Return if it can move or not
        return can_movement
            
    #Collision of the blocks in y
    def y_collision(self,mario)->bool:
        """
        function that checks if there is a collision above or under mario
        @param mario, we import data from mario on the function like its position
        """
        #colisions for the top
        go_down=True

        for i in range(self.max):
            #We check that if is above a pipe
            if i<len(self.pipe_list):
                if mario.x >= (self.pipe_list[i][0]-16) and mario.x <= (self.pipe_list[i][0]+32) and mario.y >= (self.pipe_list[i][1]-16):
                    go_down =False
            #We check that if is above a normal brick
            if i<len(self.normal_brick_list):
                if mario.x >= (self.normal_brick_list[i][0]-14) and mario.x <= (self.normal_brick_list[i][0]+14) and mario.y >= (self.normal_brick_list[i][1]-16) and mario.y < self.normal_brick_list[i][1]+3:
                    go_down =False
            #We check that if is above a question brick 
            if i<len(self.question_brick_list):
                if mario.x >= (self.question_brick_list[i][0]-14) and mario.x <= (self.question_brick_list[i][0]+14) and mario.y >= (self.question_brick_list[i][1]-16) and mario.y < self.question_brick_list[i][1]+3:
                    go_down =False
        #we set the already_jumped for mario to false so it can jump from a platform (this conditional is to avoid mario from flying)
        if not go_down:
            mario.already_jumped=False
        return go_down


    def minus_y_collision(self,mario)->bool:  
        blocked_jump = False
        for i in range(self.max):
            #We check that if is below a normal brick
            if i<len(self.normal_brick_list):
                if mario.x >= (self.normal_brick_list[i][0]-14) and mario.x <= (self.normal_brick_list[i][0]+14) and mario.y <= (self.normal_brick_list[i][1]+14) and mario.y >= (self.normal_brick_list[i][1]):
                    blocked_jump =True
            #We check that if is below a question brick 
            if i<len(self.question_brick_list):
                if mario.x >= (self.question_brick_list[i][0]-14) and mario.x <= (self.question_brick_list[i][0]+14) and mario.y <= (self.question_brick_list[i][1]+14) and mario.y >= (self.question_brick_list[i][1]):
                    blocked_jump =True
        #we set the already_jumped for mario to false so it can jump from a platform (this conditional is to avoid mario from flying)
        return blocked_jump
        