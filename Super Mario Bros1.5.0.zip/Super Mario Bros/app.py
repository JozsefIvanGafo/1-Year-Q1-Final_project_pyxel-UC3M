"""
Super mario bros game App class
description:
Here the program will create a class App that will execute the draw and update functions for the Main program
@Author: József Iván Gafo and Marcos González
@since 11/14/2021
@Version 1.0.0 
"""
import pyxel
from mario import Mario
from hud import Hud
from Objects import Objects
from enemies import Enemies
from mariocontrols import MarioControls
from power_ups import PowerUps
from enemies_collision import EnemiesCollision

class App:
    """This class execute the draw and update functions"""
    def __init__(self,width:int,height:int) :
        """This are the parameters to create the screen
        @param width, it determines the width of the screen
        @param height, it determines the height of the screen
        """
        self.screen_width=width
        self.screen_height=height
        
        #We spawn a Mario on the screen (on the top down on the left)
        self.mario=Mario(0,self.screen_height-48,False)
        #We activate the different classes
        self.hud=Hud(0,0,400)
        self.objects=Objects()
        self.enemies=Enemies()
        self.controls=MarioControls()
        self.power_ups=PowerUps()
        self.enemies_collision = EnemiesCollision()
    #Here we will put the diferent controls for mario and ennemies
    def update(self):
        """
        This function will be executed every frame, the function is in charge of updating different events like the movement of mario, ennemies.
        """
        #If we press the button escape the program will close
        if pyxel.btnp(pyxel.KEY_ESCAPE):
            pyxel.quit()
        if self.mario.mario_is_alive=="alive":
            #This method is to execute the controls of mario and avoid excessive code on app.py
            self.controls.controls_of_mario(self.mario,self.objects,self.enemies,self.power_ups,self.hud,self.enemies_collision)
            self.enemies_collision.collision_of_enemies_with_objects(self.enemies,self.objects)
            self.enemies_collision.collision_with_mario(self.enemies,self.mario,self.hud)
            self.power_ups.collision_of_mushroom_with_objects(self.objects)
            self.power_ups.mario_collision_with_mushroom(self.mario,self.hud)
        
        

    #Here we declare the draw function, where it will do the graphics part
    def draw(self):
        #We project the tilemap on the screen (It needs to be first so it doesn't overwrite Mario)
        if self.mario.mario_is_alive=="alive":
            pyxel.bltm(0, 0, 0, 0, 0, 32, 32)
            
            #We use 2 loop instead of doing a lot of single loops
            #decoration
            for i in range(self.objects.max):
                #we draw clouds
                if i< len(self.objects.cloud_list):
                    pyxel.blt(self.objects.cloud_list[i][0],self.objects.cloud_list[i][1],self.objects.sprite_cloud[0],self.objects.sprite_cloud[1],
                    self.objects.sprite_cloud[2],self.objects.sprite_cloud[3],self.objects.sprite_cloud[4],colkey=12)
                #We draw bushes
                if i < len(self.objects.bush_list):
                    pyxel.blt(self.objects.bush_list[i][0],self.objects.bush_list[i][1],self.objects.sprite_bush[0],self.objects.sprite_bush[1],
                    self.objects.sprite_bush[2],self.objects.sprite_bush[3],self.objects.sprite_bush[4],colkey=12)
            #obstacles
            for i in range(self.objects.max):
                #We draw all normal bricks
                if i< len(self.objects.normal_brick_list):
                    pyxel.blt(self.objects.normal_brick_list[i][0],self.objects.normal_brick_list[i][1],self.objects.sprite_normal_brick[0],self.objects.sprite_normal_brick[1],
                    self.objects.sprite_normal_brick[2],self.objects.sprite_normal_brick[3],self.objects.sprite_normal_brick[4],colkey=12)

                #We draw all questions bricks
                if i< len(self.objects.question_brick_list):
                    pyxel.blt(self.objects.question_brick_list[i][0],self.objects.question_brick_list[i][1],self.objects.sprite_question_brick[0],self.objects.sprite_question_brick[1],
                    self.objects.sprite_question_brick[2],self.objects.sprite_question_brick[3],self.objects.sprite_question_brick[4])
                #We draw an empty block
                if i< len(self.objects.empty_block):
                    pyxel.blt(self.objects.empty_block[i][0],self.objects.empty_block[i][1],self.objects.sprite_empty_block[0],self.objects.sprite_empty_block[1],
                    self.objects.sprite_empty_block[2],self.objects.sprite_empty_block[3],self.objects.sprite_empty_block[4])

                #We draw all pipes
                if i< len(self.objects.pipe_list):
                    pyxel.blt(self.objects.pipe_list[i][0],self.objects.pipe_list[i][1],self.objects.sprite_pipe[0],self.objects.sprite_pipe[1],
                    self.objects.sprite_pipe[2],self.objects.sprite_pipe[3],self.objects.sprite_pipe[4],colkey=12)

            #We spawn the enemies
            self.enemies.print_ennemies_on_the_screen()
            if self.mario.super_mario == False:
                #Animation of Mario
                #Mario jumping
                if (self.mario.initial_height[0] or self.mario.y != self.mario.initial_height[1]) and not( self.mario.on_platform and  not self.mario.already_jumped):
                    pyxel.blt(self.mario.x, self.mario.y, self.mario.sprite_jump[0],
                        self.mario.sprite_jump[1], self.mario.sprite_jump[2], self.mario.sprite_jump[3],
                        self.mario.sprite_jump[4],colkey=0)
                #Mario on the floor
                else:
                    pyxel.blt(self.mario.x, self.mario.y, self.mario.sprite[0],
                        self.mario.sprite[1], self.mario.sprite[2], self.mario.sprite[3],
                        self.mario.sprite[4],colkey=0)
                        
            else:
                """"
                if (self.mario.initial_height[0] or self.mario.y != self.mario.initial_height[1]) and not( self.mario.on_platform and  not self.mario.already_jumped):
                    pyxel.blt(self.mario.x, self.mario.y, self.mario.super_mario.jump.sprite[0],
                        self.mario.super_mario.jump.sprite[1], self.mario.super_mario.jump.sprite[2], self.mario.super_mario.jump.sprite[3],
                        self.mario.super_mario.jump.sprite[4],colkey=0)
                else:"""
                pyxel.blt(self.mario.x, self.mario.y, self.mario.super_mario_looking_right[0],
                        self.mario.super_mario_looking_right[1], self.mario.super_mario_looking_right[2], self.mario.super_mario_looking_right[3],
                        self.mario.super_mario_looking_right[4],colkey=0)

            self.power_ups.print_mushrooms()
                        
            #Here we draw the timer starting from 256
            pyxel.text(self.screen_width-40,10,"TIME:"+str(int(self.hud.timer(self.mario))),7)
            #We print the hud on the screen
            pyxel.text(90,10,"Coins X "+str(int(self.hud.coins)),7)
            pyxel.text(10,10,"MARIO",7)
            pyxel.text(10,20,"score: "+str(int(self.hud.score)),7)
            pyxel.text(140,10,str(self.mario.x)+", "+str(self.mario.y),7)
            
        else:
            pyxel.cls(0)
            pyxel.text(70,110,"You are dead ",7)
            pyxel.text(70,120," press escape to exit the program",7)
            pyxel.text(70,130," thanks for playing Super Mario",7)
