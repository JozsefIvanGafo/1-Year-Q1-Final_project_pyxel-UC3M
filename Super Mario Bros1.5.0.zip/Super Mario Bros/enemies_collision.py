"""
Super mario bros game
description:
This class will be in charge of the collisions of the enemies
@Author: József Iván Gafo and Marcos González
@since 11/14/2021
@Version 0.0.1
"""
import pyxel
from mario import Mario
from Objects import Objects
from enemies import Enemies
from hud import Hud
class EnemiesCollision():
    def collision_of_enemies_with_objects(self,enemies:object,objects:object):
        """
        This method is in charge to execute all the conditionals that allow to move the enemies with collision of the objects.
        The reason is to avoid excessive code on app.py
        @param enemies, here we import all the data  from mario that is on app.py
        @param objects, here we import all the data from objects that is on app.py
        """
        
        for i in range(len(enemies.spawn_coordinates)):
            if enemies.looking_right[i] and enemies.status_enemy[i]=="alive":
                for j in range(objects.max):
                    #If there is a pipe in front
                    if j<len(objects.pipe_list):
                        if (enemies.spawn_coordinates[i][0]) >= (objects.pipe_list[j][0]-16) and enemies.spawn_coordinates[i][0] <= (objects.pipe_list[j][0]+32)and enemies.spawn_coordinates[i][1] >= objects.pipe_list[j][1]:
                            enemies.looking_right[i]=False
                         
                    #If there is a normal block in front
                    if j<len(objects.normal_brick_list):   
                        if enemies.spawn_coordinates[i][0] >= (objects.normal_brick_list[j][0]-12) and enemies.spawn_coordinates[i][0] <= (objects.normal_brick_list[j][0])and enemies.spawn_coordinates[i][1] >=objects.normal_brick_list[j][1]-8 and enemies.spawn_coordinates[i][1] <= objects.normal_brick_list[j][1]+3:   #self.normal_brick_list[i][1]: #and other.y<self.normal_brick_list[i][1]-8:
                            enemies.looking_right[i]=False
                          
                    #If there is a question brick in front
                    if j<len(objects.question_brick_list):   
                        if enemies.spawn_coordinates[i][0] >= (objects.question_brick_list[j][0]-12) and enemies.spawn_coordinates[i][0] <= (objects.question_brick_list[j][0])and enemies.spawn_coordinates[i][1] >= objects.question_brick_list[j][1]-8 and enemies.spawn_coordinates[i][1] <= objects.question_brick_list[j][1]+3:
                            enemies.looking_right[i]=False
                           
            #If not looking right
            elif enemies.status_enemy[i]=="alive":
                
                for j in range(objects.max):
                    #If there is a pipe behind
                    if j<len(objects.pipe_list):
                        if enemies.spawn_coordinates[i][0] <= (objects.pipe_list[j][0]+34) and enemies.spawn_coordinates[i][0] >= (objects.pipe_list[j][0]-14) and enemies.spawn_coordinates[i][1] >= objects.pipe_list[j][1]:
                            enemies.looking_right[i]=True
                    #If there is a normal block behind
                    if j<len(objects.normal_brick_list):   
                        if enemies.spawn_coordinates[i][0] <= (objects.normal_brick_list[j][0]+16) and enemies.spawn_coordinates[i][0] >= (objects.normal_brick_list[j][0]) and enemies.spawn_coordinates[i][1] >= objects.normal_brick_list[j][1]-8 and enemies.spawn_coordinates[i][1] <= objects.normal_brick_list[j][1]+3:
                            enemies.looking_right[i]=True
                    #IF there is a question brick behind
                    if j<len(objects.question_brick_list):   
                        if enemies.spawn_coordinates[i][0] <= (objects.question_brick_list[j][0]+16) and enemies.spawn_coordinates[i][0] >= (objects.question_brick_list[j][0]) and enemies.spawn_coordinates[i][1] >= objects.question_brick_list[j][1]-8 and enemies.spawn_coordinates[i][1] <= objects.question_brick_list[j][1]+3:
                            enemies.looking_right[i]=True
                    
            enemies.update_coordinates_for_ennemies(i)

    def collision_with_mario(self,enemies:object,mario:object,hud:object):
        """
        This method is in charge to execute all the conditionals that check the collision of the enemies with mario.
        @param enemies, here we import all the data  from mario that is on app.py
        @param objects, here we import all the data from objects that is on app.py
        @param hud, here we import all the data from hud that is an oobject on app.py
        """
        for i in range(len(enemies.spawn_coordinates)):  
            if mario.x >= (enemies.spawn_coordinates[i][0]-18) and mario.x <= (enemies.spawn_coordinates[i][0]+8) and mario.y == (enemies.spawn_coordinates[i][1]-16) and mario.y < enemies.spawn_coordinates[i][1]-2:
                enemies.status_enemy[i]="dead"
                
                print("The enemy is dead")
                hud.score_increase(1000)

            elif mario.x >= (enemies.spawn_coordinates[i][0]-14) and mario.x <= (enemies.spawn_coordinates[i][0]) and mario.y <= enemies.spawn_coordinates[i][1]+16 and mario.y >=enemies.spawn_coordinates[i][1]:
                if enemies.status_enemy[i]!="dead":
                    print("dead from the right")
                    mario.mario_is_alive="dead"
            elif mario.x <= (enemies.spawn_coordinates[i][0]+16) and mario.x >= (enemies.spawn_coordinates[i][0]) and mario.y <= enemies.spawn_coordinates[i][1]+16 and mario.y >= enemies.spawn_coordinates[i][1]:
                if enemies.status_enemy[i]!="dead":
                    print("dead from the left")
                    mario.mario_is_alive="dead"
                
            
            
                
            