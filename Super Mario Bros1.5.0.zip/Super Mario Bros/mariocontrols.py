"""
Super mario bros game
description:
This class will be in charge to do the controsl of mario so we avoid excessive code in app.py
@Author: József Iván Gafo and Marcos González
@since 11/14/2021
@Version 0.0.1
"""
import pyxel
from mario import Mario
from Objects import Objects
from enemies import Enemies
from hud import Hud
from power_ups import PowerUps


class MarioControls:
    def controls_of_mario(self,mario:object,object:object,enemies:object,power_ups,hud,enemies_collision):
        """
        This method is in charge to execute all the conditionals that allow to move the mario and the objects.
        The reason is to avoid excessive code on app.py
        @param mario, here we import all the data  from mario that is on app.py
        @param other, here we import all the data from objects that is on app.py
        """
        #We check that the parameters are objects
        if (type(mario) and type(object))==object:
            raise TypeError ("mario and other parameters needs to be objects from app.py")
        else:  
            #If the user press the right key or D mario will move to the right (hold,period are paramaters so you can hold the key and mario will move)
            if (pyxel.btnp(pyxel.KEY_RIGHT,hold=1,period=1))  or (pyxel.btnp(pyxel.KEY_D,hold=1,period=1)):
                #We execute a method from objects to determine if mario can move to the right
                can_movement=object.x_collision(mario,True,False)
                if can_movement:
                    mario.movement("right")
        
            #If the user press the left key or A mario will move to the left (hold,period are paramaters so you can hold the key and mario will move)
            elif pyxel.btnp(pyxel.KEY_LEFT,hold=1,period=1)  or pyxel.btnp(pyxel.KEY_A,hold=1,period=1):
                #We execute a method from objects to determine if mario can move to the left
                can_movement=object.x_collision(mario,False,True)
                if can_movement:
                    mario.movement("left")
        
            #If the user press the up key or space or w mario will move to the right (hold,period are paramaters so you can hold the key and mario will move)    
            if (pyxel.btnp(pyxel.KEY_UP))  or (pyxel.btnp(pyxel.KEY_SPACE)) or (pyxel.btnp(pyxel.KEY_W)):
                
                if (mario.initial_height[0]==False  and mario.y == mario.initial_height[1]) or mario.on_platform and not mario.already_jumped :
                    #If mario is on the floor we change to True and we take the initial height so mario starts to jump
                    mario.initial_height=[True,mario.y]
                    mario.on_platform=False
                    mario.movement("jump")
                    mario.already_jumped=True
            blocked_jump = object.minus_y_collision(mario,power_ups,hud)
            #If mario is on the air , he will continue jumping until he reaches the maximum height of jump (logic on mario class)
            if mario.initial_height[0]==True and not blocked_jump:
                mario.movement("jump")
            else:
                mario.initial_height[0]=False
            #We check that if there is a collision or not, if there is a collision mario will not go down
            go_down=object.y_collision(mario)
        
            #If go down is true mario then will start going down
            if go_down:
                mario.movement("down")
                mario.on_platform=True

            #If mario  on middle screen then we move the objects to the left
            if mario.middle_screen:
                object.update_coordinates()
                enemies_collision.collision_of_enemies_with_objects(enemies,object)
                power_ups.collision_of_mushroom_with_objects(object)
                mario.middle_screen=False
                