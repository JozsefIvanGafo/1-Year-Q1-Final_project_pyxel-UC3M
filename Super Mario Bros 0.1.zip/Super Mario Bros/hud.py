"""
Super mario bros game hud class
description:
Here the program will create a class hud that will draw the lives, coins, score and time for the program
@Author: József Iván Gafo and Marcos González
@since 11/14/2021
@Version 0.0.1
"""
import pyxel
import time
class Hud:
    """This class handle the score, the time, the coins counter and the lives"""
    def __init__(self,coins:int,score:int,time:int):
        self.coins = coins
        self.score = score
        self.time = time
    
    def timer(self,frame:int):
        """This method defines the timer (countdown)"""
        actual_time= self.time-0.029
        if actual_time < 0:
            self.time = 0
        else:
            self.time=actual_time
        return self.time