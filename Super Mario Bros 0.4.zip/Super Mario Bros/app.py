"""
Super mario bros game App class
description:
Here the program will create a class App that will execute the draw and update functions for the Main program
@Author: József Iván Gafo and Marcos González
@since 11/14/2021
@Version 0.0.1 apsp
"""
import pyxel
from mario import Mario
from hud import Hud
from Objects import Objects

class App:
    """This class execute the draw and update functions"""
    def __init__(self,width:int,height:int) :
        """This are the parameters to create the screen
        """
        self.screen_width=width
        self.screen_height=height
        #We spawn a Mario on the screen (on the top down on the left)
        self.mario=Mario(0,self.screen_height-48,False,False)
        #We activate the hud class with 256
        self.hud=Hud(0,0,256)
        self.objects=Objects()

    #Here we will put the diferent controls for mario and ennemies
    def update(self):
        #If we press the button escape the program will close
        if pyxel.btnp(pyxel.KEY_ESCAPE):
            pyxel.quit()

        #If the user press the right key or D mario will move to the right (hold,period are paramaters so you can hold the key and mario will move)
        if (pyxel.btnp(pyxel.KEY_RIGHT,hold=1,period=1))  or (pyxel.btnp(pyxel.KEY_D,hold=1,period=1)):
            self.mario.movement("right")

        #If the user press the left key or A mario will move to the left (hold,period are paramaters so you can hold the key and mario will move)
        elif pyxel.btnp(pyxel.KEY_LEFT,hold=1,period=1)  or pyxel.btnp(pyxel.KEY_A,hold=1,period=1):
            self.mario.movement("left")

        #If the user press the up key or space or w mario will move to the right (hold,period are paramaters so you can hold the key and mario will move)    
        if (pyxel.btnp(pyxel.KEY_UP))  or (pyxel.btnp(pyxel.KEY_SPACE)) or (pyxel.btnp(pyxel.KEY_W)):
            #We check that mario is on the floor (false) or if he is in a surface, he cannot jump until he is in a surface again.
            if self.mario.initial_height[0]==False and self.mario.y == self.mario.initial_height[1]:
                #If mario is on the floor we change to True and we take the initial height so mario starts to jump
                self.mario.initial_height=[True,self.mario.y]
                self.mario.movement("jump")
            #If we press again jump mario will stop jumping
            elif self.mario.initial_height[0]==True:
                self.mario.movement("jump")
            """ Extra if we want to make shorter jumps
            else:
                self.mario.initial_height[0]=False
            """
        #If mario is on the air , he will continue jumping until he reaches the maximum height of jump (logic on mario class)
        elif self.mario.initial_height[0]==True:
            self.mario.movement("jump")

        #Else the gravity will keep mario down
        if  self.mario.initial_height[0]==False:
            self.mario.movement("down")

        #If mario  on middle screen then we move the objects to the left
        if self.mario.middle_screen:
            self.objects=Objects(self.mario.course)
            self.mario.middle_screen=False
            

    #Here we declare the draw function, where it will do the graphics part
    def draw(self):
        #We project the tilemap on the screen (It needs to be first so it doesn't overwrite Mario)
        pyxel.bltm(0, 0, 0, (0+self.mario.course)/7.2, 0, 32, 32)
        
        #We draw all normal bricks
    
        for i in range(len(self.objects.normal_brick_list)):
            pyxel.blt(self.objects.normal_brick_list[i][0],self.objects.normal_brick_list[i][1],self.objects.sprite_normal_brick[0],self.objects.sprite_normal_brick[1],
            self.objects.sprite_normal_brick[2],self.objects.sprite_normal_brick[3],self.objects.sprite_normal_brick[4])

        #We draw all questions bricks

        for i in range(len(self.objects.question_brick_list)):
            pyxel.blt(self.objects.question_brick_list[i][0],self.objects.question_brick_list[i][1],self.objects.sprite_question_brick[0],self.objects.sprite_question_brick[1],
            self.objects.sprite_question_brick[2],self.objects.sprite_question_brick[3],self.objects.sprite_question_brick[4])

        #We draw all clouds

        for i in range(len(self.objects.cloud_list)):
            pyxel.blt(self.objects.cloud_list[i][0],self.objects.cloud_list[i][1],self.objects.sprite_cloud[0],self.objects.sprite_cloud[1],
            self.objects.sprite_cloud[2],self.objects.sprite_cloud[3],self.objects.sprite_cloud[4])
        
        #We draw all bushes

        for i in range(len(self.objects.bush_list)):
            pyxel.blt(self.objects.bush_list[i][0],self.objects.bush_list[i][1],self.objects.sprite_bush[0],self.objects.sprite_bush[1],
            self.objects.sprite_bush[2],self.objects.sprite_bush[3],self.objects.sprite_bush[4])

        #We draw all pipes

        for i in range(len(self.objects.pipe_list)):
            pyxel.blt(self.objects.pipe_list[i][0],self.objects.pipe_list[i][1],self.objects.sprite_pipe[0],self.objects.sprite_pipe[1],
            self.objects.sprite_pipe[2],self.objects.sprite_pipe[3],self.objects.sprite_pipe[4])



        """We draw Mario taking the values from the mario object 
        invoked on the App __init__ class
        @param x
        @param y
        @image bank
        @start x in pyxeleditor
        @start y in pyxeleditor
        @size16x16
        @colkey=0 is so that mario background on the sprite is transparent"""
        pyxel.blt(self.mario.x, self.mario.y, self.mario.sprite[0],
                  self.mario.sprite[1], self.mario.sprite[2], self.mario.sprite[3],
                  self.mario.sprite[4],colkey=0)
        if self.mario.initial_height[0] == True or self.mario.y != self.mario.initial_height[1]:
            pyxel.blt(self.mario.x, self.mario.y, self.mario.sprite_jump[0],
                  self.mario.sprite_jump[1], self.mario.sprite_jump[2], self.mario.sprite_jump[3],
                  self.mario.sprite_jump[4],colkey=0)
        #Here we draw the timer starting from 256
        pyxel.text(self.screen_width-40,10,"TIME:"+str(int(self.hud.timer(pyxel.frame_count))),7)
        #We print the hud on the screen
        pyxel.text(90,10,"X 00",7)
        pyxel.text(10,10,"MARIO",7)
        pyxel.text(10,20,"000000",7)
        pyxel.text(140,10,str(self.mario.x)+", "+str(self.mario.y),7)