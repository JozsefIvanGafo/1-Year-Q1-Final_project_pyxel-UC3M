"""
Super mario bros game
description:
Here the program will create the class Mario that will be in charge of all the things related to mario
@Author: József Iván Gafo and Marcos González
@since 11/14/2021
@Version 0.0.1
"""
import pyxel
class Mario:
    """This class stores all the information about the entetie of Mario"""
    def __init__(self,x:int,y:int,middle_of_the_screen:bool,god_mode:bool):
        """This method creates/spawns mario on such coordinates
        @param x the starting x pos of Mario
        @param y the starting y pos of Mario
        @param looking_right is a bool that indicates that mario 
        is looking right (True/False)
        @param  middle_of_the screen 
        @param god mario where almost freely
        """
        #We define the position of where to spwan Mario
        self.x=x
        self.y=y
        self.middle_screen=middle_of_the_screen
        #Here we define the sprite of Mario (bank,x pos on the bank, y pos on the bank, size height x base)
        self.sprite=(0,0,48,16,16)
        self.sprite_jump = (0,0,120,16,16)

        #The course that mario will travel (This attribute will be used to substractthe x on Objects)
        self.course=0
        #We use an atribut god mode where Mario can move freely
        self.god_mode=god_mode
        #Attributes used for taking coordinates for the jump
        self.initial_height=[False,y]
        
    
    #We define the basic movement for mario(Do not forget to later put a parameter for the size of mushroom)
    def movement(self,direction:str):
        """
        This method defines the movment of mario
        @param direction is where mario will move next
        """
        #To check that the values are correct
        if direction.lower() in ("right","left","jump","down"):

            #Where the order is receive mario moves to the right (x+2)
            if direction.lower()=="right":
                #MArio moves to the right until the middle of the screen
                if self.x<112 or self.god_mode:
                    self.x=self.x+2
                #When mario is on the center mario stop to move and middle of the screen 
                # is true and we add to course +2 that we will substract to objects
                else:
                    self.middle_screen=True
                    self.course+=2
                
                
            #Where mmario receives the order to move to the right (x-2)
            elif direction.lower()=="left":
                if self.x <=0:
                    self.x = 0
                else:
                    self.x=self.x-2

            #Where the order is receive mario moves to the right (y-2)
            if direction.lower()=="jump":
                if self.y > (self.initial_height[1] - 64):
                    self.y -= 4
                elif self.y<=(self.initial_height[1] - 64):
                    self.initial_height[0]=False
                    
            #Where mmario receives the order to move to the right (y+2)
            elif direction.lower()=="down":
                if self.y >= 208:
                    self.y = 208
                else:
                    self.y=self.y+3

        #Else we raise an error and we close the program
        else:
            raise ValueError("To use the direction fun. of Mario the direction must be right or left or jump or down, check if you misspelled in your program using this function")

    