"""
Super mario bros game
description:
Here the program will create the class enemies to spawn all the enemies
@Author: József Iván Gafo and Marcos González
@since 11/14/2021
@Version 0.0.1
"""
from mario import Mario
import random
class Enemies(Mario):
    def __init__(self,x_change:int):
        #bank, coord on the bank x, y and the size mxn
        self.sprite_goomba= (0,32,48,16,16)
        self.sprite_koopa = (0,48,40,16,32)
        #spawnrate koopa(25%) and goomba(75%)
        self.spawn_list = [25,75]
        #Max of ennemies
        self.max_ennemies=4
        self.ennemies_on_screen=0
        self.spawn_coordinates=[150-x_change]
    def spawn(self):
        if self.ennemies_on_screen<=self.max_ennemies:
            random_number = random.randint(1,100)
        if random_number>self.spawn_list[0]:
            return "goomba"

        else:
            return "koopa"