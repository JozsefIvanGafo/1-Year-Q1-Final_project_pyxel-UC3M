"""
Super mario bros game
description:
Here the program will create the class objects to create all the objects such as pipes, blocks etc.
@Author: József Iván Gafo and Marcos González
@since 11/14/2021
@Version 0.0.1
"""
import pyxel
from mario import Mario
class Objects:
    def __init__(self,x_change:int=0) :
        #Here we put variables for the x and y for breakable bricks
        x_normal_brick=[128,160]
        y_normal_brick=[176,176]
        
        self.normal_brick_list = []
        for i in range(len(x_normal_brick)):
            brick=[x_normal_brick[i]-x_change,y_normal_brick[i]]
            self.normal_brick_list.append(brick)

        #Here we put the x and y for the question bricks
        x_question_brick=[144,144]
        y_question_brick=[128,176]

        self.question_brick_list = []
        for i in range(len(x_question_brick)):
            question_brick=[x_question_brick[i]-x_change,y_question_brick[i]]
            self.question_brick_list.append(question_brick)

        #Sprites for every block
        self.sprite_question_brick=(0,16,0,16,16)
        self.sprite_normal_brick=(0,0,16,16,16)