"""
Super mario bros game App class
description:
Here the program will create a class App that will execute the draw and update functions for the Main program
@Author: József Iván Gafo and Marcos González
@since 11/14/2021
@Version 1.0.0 
"""
import pyxel
from mario import Mario
from hud import Hud
from Objects import Objects
from enemies import Enemies
from mariocontrols import MarioControls

class App:
    """This class execute the draw and update functions"""
    def __init__(self,width:int,height:int) :
        """This are the parameters to create the screen
        @param width, it determines the width of the screen
        @param height, it determines the height of the screen
        """
        self.screen_width=width
        self.screen_height=height
        
        #We spawn a Mario on the screen (on the top down on the left)
        self.mario=Mario(0,self.screen_height-48,False)
        #We activate the different classes
        self.hud=Hud(0,0,256)
        self.objects=Objects()
        self.enemies=Enemies(self.mario.course)
        self.controls=MarioControls()

    #Here we will put the diferent controls for mario and ennemies
    def update(self):
        """
        This function will be executed every frame, the function is in charge of updating different events like the movement of mario, ennemies.
        """
        #If we press the button escape the program will close
        if pyxel.btnp(pyxel.KEY_ESCAPE):
            pyxel.quit()
        #This method is to execute the controls of mario and avoid excessive code on app.py
        self.controls.controls_of_mario(self.mario,self.objects)


    #Here we declare the draw function, where it will do the graphics part
    def draw(self):
        #We project the tilemap on the screen (It needs to be first so it doesn't overwrite Mario)
        pyxel.bltm(0, 0, 0, (0+self.mario.course)/7.2, 0, 32, 32)
        
        #We use a loop instead of doing a lot of single loops
        for i in range(self.objects.max):
            #We draw all clouds
            if i< len(self.objects.cloud_list):
                pyxel.blt(self.objects.cloud_list[i][0],self.objects.cloud_list[i][1],self.objects.sprite_cloud[0],self.objects.sprite_cloud[1],
                self.objects.sprite_cloud[2],self.objects.sprite_cloud[3],self.objects.sprite_cloud[4],colkey=12)
        
            #We draw all bushes
            if i < len(self.objects.bush_list):
                pyxel.blt(self.objects.bush_list[i][0],self.objects.bush_list[i][1],self.objects.sprite_bush[0],self.objects.sprite_bush[1],
                self.objects.sprite_bush[2],self.objects.sprite_bush[3],self.objects.sprite_bush[4],colkey=12)

            #We draw all normal bricks
            if i< len(self.objects.normal_brick_list):
                pyxel.blt(self.objects.normal_brick_list[i][0],self.objects.normal_brick_list[i][1],self.objects.sprite_normal_brick[0],self.objects.sprite_normal_brick[1],
                self.objects.sprite_normal_brick[2],self.objects.sprite_normal_brick[3],self.objects.sprite_normal_brick[4],colkey=12)

            #We draw all questions bricks
            if i< len(self.objects.question_brick_list):
                pyxel.blt(self.objects.question_brick_list[i][0],self.objects.question_brick_list[i][1],self.objects.sprite_question_brick[0],self.objects.sprite_question_brick[1],
                self.objects.sprite_question_brick[2],self.objects.sprite_question_brick[3],self.objects.sprite_question_brick[4])

            #We draw all pipes
            if i< len(self.objects.pipe_list):
                pyxel.blt(self.objects.pipe_list[i][0],self.objects.pipe_list[i][1],self.objects.sprite_pipe[0],self.objects.sprite_pipe[1],
                self.objects.sprite_pipe[2],self.objects.sprite_pipe[3],self.objects.sprite_pipe[4],colkey=12)

        #Animation of Mario
        #Mario jumping
        if (self.mario.initial_height[0] or self.mario.y != self.mario.initial_height[1]) and not( self.mario.on_platform and  not self.mario.already_jumped):
            pyxel.blt(self.mario.x, self.mario.y, self.mario.sprite_jump[0],
                  self.mario.sprite_jump[1], self.mario.sprite_jump[2], self.mario.sprite_jump[3],
                  self.mario.sprite_jump[4],colkey=0)
        #Mario on the floor
        else:
            pyxel.blt(self.mario.x, self.mario.y, self.mario.sprite[0],
                  self.mario.sprite[1], self.mario.sprite[2], self.mario.sprite[3],
                  self.mario.sprite[4],colkey=0)
        

        #Here we are going to draw the enemies
        spawn_rate=self.enemies.spawn()
        if spawn_rate=="goomba":
            pyxel.blt(self.enemies.spawn_coordinates[0], self.objects.floor, self.enemies.sprite_goomba[0],
                    self.enemies.sprite_goomba[1], self.enemies.sprite_goomba[2], self.enemies.sprite_goomba[3],
                    self.enemies.sprite_goomba[4],colkey=12)
                    
                    
        #Here we draw the timer starting from 256
        pyxel.text(self.screen_width-40,10,"TIME:"+str(int(self.hud.timer(pyxel.frame_count))),7)
        #We print the hud on the screen
        pyxel.text(90,10,"Coins X 00",7)
        pyxel.text(10,10,"MARIO",7)
        pyxel.text(10,20,"00000000",7)
        pyxel.text(140,10,str(self.mario.x)+", "+str(self.mario.y),7)