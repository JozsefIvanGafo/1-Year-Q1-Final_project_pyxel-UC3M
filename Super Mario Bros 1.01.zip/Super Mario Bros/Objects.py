"""
Super mario bros game
description:
Here the program will create the class objects to create all the objects such as pipes, blocks etc.
@Author: József Iván Gafo and Marcos González
@since 11/14/2021
@Version 0.0.1
"""
import pyxel
from mario import Mario
class Objects:
    def __init__(self,x_change:int=0) :
        self.floor=208
        #Here we put variables for the x and y for breakable bricks
        x_normal_brick=[128,160]
        y_normal_brick=[176,176]
        
        self.normal_brick_list = []
        for i in range(len(x_normal_brick)):
            brick=[x_normal_brick[i]-x_change,y_normal_brick[i]]
            self.normal_brick_list.append(brick)

        #Here we put the x and y for the question bricks
        x_question_brick=[144,144,176]
        y_question_brick=[128,176,208]

        self.question_brick_list = []
        for i in range(len(x_question_brick)):
            question_brick=[x_question_brick[i]-x_change,y_question_brick[i]]
            self.question_brick_list.append(question_brick)

        #Here we put the x and y for the clouds

        x_cloud=[15,70,120,170,240,300,370,430,500]
        y_cloud=[15,60,2,40,24,55,20,60,34]
        
        self.cloud_list = []
        for i in range(len(x_cloud)):
            cloud=[x_cloud[i]-x_change,y_cloud[i]]
            self.cloud_list.append(cloud)

        #Here we put the x and y for the bushes

        x_bush=[15,170,300,400,500]
        y_bush=[208,208,208,208,208]
        
        self.bush_list = []
        for i in range(len(x_bush)):
            bush=[x_bush[i]-x_change,y_bush[i]]
            self.bush_list.append(bush)

        #Here we put the x and y for the pipes
        self.size_pipe=32
        x_pipe=[65,290]
        y_pipe=[192,192]
        
        self.pipe_list = []
        for i in range(len(x_pipe)):
            pipe=[x_pipe[i]-x_change,y_pipe[i]]
            self.pipe_list.append(pipe)


        #Sprites for every block
        self.sprite_question_brick=(0,16,0,16,16)
        self.sprite_normal_brick=(0,0,16,16,16)
        self.sprite_cloud=(0,16,64,48,24)
        self.sprite_bush=(0,16,88,48,16)
        self.sprite_pipe=(0,32,0,32,32)
        #max length
        max_length=[len(x_bush),len(x_cloud),len(x_normal_brick),len(x_pipe),len(x_question_brick)]
        self.max=max(max_length)
    #colision of the blocks in x
    def x_collision(self,other,x:bool=False,minus_x:bool=False):
        can_movement=True
        #If there is a collision on front
        if x:
            #We check that all coordinates of the pipes and if they are near of mario we return false where mario cannot continue 16
            for i in range(self.max):
                if i<len(self.pipe_list):
                    if other.x >= (self.pipe_list[i][0]-16)  and other.y > self.pipe_list[i][1] and other.x <= (self.pipe_list[i][0]+32):
                        can_movement =False

                if i<len(self.normal_brick_list):   
                    if other.x >= (self.normal_brick_list[i][0]-12) and other.x <= (self.normal_brick_list[i][0]) and other.y >self.normal_brick_list[i][1]-8 and other.y < self.normal_brick_list[i][1]+3:   #self.normal_brick_list[i][1]: #and other.y<self.normal_brick_list[i][1]-8:
                        can_movement =False
                if i<len(self.question_brick_list):   
                    if other.x >= (self.question_brick_list[i][0]-12) and other.x <= (self.question_brick_list[i][0]) and other.y >= self.question_brick_list[i][1]-8 and other.y <= self.question_brick_list[i][1]+3:
                        can_movement =False
            return can_movement
        #If there is a collision on the back of mario
        if minus_x:
            for i in range(self.max):
                if i<len(self.pipe_list):
                    if other.x <= (self.pipe_list[i][0]+34) and other.x >= (self.pipe_list[i][0]-14) and other.y > self.pipe_list[i][1]:
                        can_movement =False
                if i<len(self.normal_brick_list):   
                    if other.x <= (self.normal_brick_list[i][0]+16) and other.x >= (self.normal_brick_list[i][0]) and other.y > self.normal_brick_list[i][1]-8 and other.y < self.normal_brick_list[i][1]+3:
                        can_movement =False
                if i<len(self.question_brick_list):   
                    if other.x <= (self.question_brick_list[i][0]+16) and other.x >= (self.question_brick_list[i][0]) and other.y >= self.question_brick_list[i][1]-8 and other.y <= self.question_brick_list[i][1]+3:
                        can_movement =False

            return can_movement
            
    #Collision of the blocks in y
    def y_collision(self,other):
        #colisions from the top

        can_movement=True
        for i in range(self.max):
            if i<len(self.pipe_list):
                if other.x >= (self.pipe_list[i][0]-16) and other.x <= (self.pipe_list[i][0]+32) and other.y >= (self.pipe_list[i][1]-16):
                    can_movement =False
        for i in range(self.max):
            if i<len(self.normal_brick_list):
                if other.x >= (self.normal_brick_list[i][0]-8) and other.x <= (self.normal_brick_list[i][0]+8) and other.y >= (self.normal_brick_list[i][1]-16) and other.y < self.normal_brick_list[i][1]+3:
                    can_movement =False
        for i in range(self.max):
            if i<len(self.question_brick_list):
                if other.x >= (self.question_brick_list[i][0]-8) and other.x <= (self.question_brick_list[i][0]+8) and other.y >= (self.question_brick_list[i][1]-16) and other.y < self.question_brick_list[i][1]+3:
                    can_movement =False
        return can_movement
        