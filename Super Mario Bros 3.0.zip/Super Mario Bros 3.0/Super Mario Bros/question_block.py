from pipes import Pipes
class Question_block(Pipes):
    """
    This class will be responsible to manage the object Question_block with inheritance of Pipes (update coordinates)
    """
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.name="question block"
        self.sprite = (0,16,0,16,16)
        self.alive=True
    def hitted(self):
        self.name="empty block"
        self.sprite = (0,16,16,16,16)
        
    """ The only setters needed because we change the sprite and name """
    @property
    def sprite(self):
        return self.__sprite
    @sprite.setter
    def sprite(self,new_value):
        if type(new_value)!=tuple:
            raise TypeError("The y should be an tuple")
        else:
            if new_value==(0,16,0,16,16) or new_value==(0,16,16,16,16):
                self.__sprite=new_value
            else:
                self.__sprite=(0,16,0,16,16)
    @property
    def name(self):
        return self.__name
    @name.setter
    def name(self,new_value):
        if type(new_value)!=str:
            raise TypeError("The y should be an str")
        else:
            if new_value=="question block" or new_value=="empty block":
                self.__name=new_value
            else:
                self.__name="question block"