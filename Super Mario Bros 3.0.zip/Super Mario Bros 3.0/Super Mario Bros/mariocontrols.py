"""
Super mario bros game
description:
This class will be in charge to do the controsl of mario so we avoid excessive code in app.py
@Author: József Iván Gafo and Marcos González
@since 11/14/2021
@Version 0.0.1
"""
import pyxel
from collision_template import Collision_template


class MarioControls:
    """
    This class is to put all the logic of mario like jumping,down, going right or left or if its on the middle screen
    Primary use: Avoid to put a lot of code on app, so it looks clean
    """
    def controls_of_mario(self,mario:object,object:object,enemies:object,power_ups,hud):
        """
        This method is in charge to execute all the conditionals that allow to move the mario and the objects.
        The reason is to avoid excessive code on app.py
        @param mario, here we import all the data  from mario that is on app.py
        @param object, here we import all the data from objects that is on app.py
        @param enemies, here we import all the data from objects that is on app.py
        @param power_ups, here we import all the data from power_ups that is on app.py
        @param hud, here we import all the data from hud that is on app.py
        """
        #We check that the parameters are objects
        if (type(mario) and type(object) and type(enemies) and type(power_ups) and (hud))==object:
            raise TypeError ("Check the parameters of mario controls, they  need to be an object from app.py")
        else:  
            #If the user press the right key or D mario will move to the right (hold,period are paramaters so you can hold the key and mario will move)
            if (pyxel.btnp(pyxel.KEY_RIGHT,hold=1,period=1))  or (pyxel.btnp(pyxel.KEY_D,hold=1,period=1)):
                #We execute a method from objects to determine if mario can move to the right
                can_movement=True
                for j in range(len(object.blocks_list)):
                    if not Collision_template.x_collision(self,mario.x,mario.y,object.blocks_list[j].x,object.blocks_list[j].y,True,object.blocks_list[j].name,object.blocks_list[j].alive,mario.super_mario_size_mushroom):
                        can_movement=False
                if can_movement:
                    mario.movement("right")
        
            #If the user press the left key or A mario will move to the left (hold,period are paramaters so you can hold the key and mario will move)
            elif pyxel.btnp(pyxel.KEY_LEFT,hold=1,period=1)  or pyxel.btnp(pyxel.KEY_A,hold=1,period=1):
                #We execute a method from objects to determine if mario can move to the left
                can_movement=True
                for j in range(len(object.blocks_list)):
                    if not Collision_template.x_collision(self,mario.x,mario.y,object.blocks_list[j].x,object.blocks_list[j].y,False,object.blocks_list[j].name,object.blocks_list[j].alive,mario.super_mario_size_mushroom):
                        can_movement=False
                if can_movement:
                    mario.movement("left")
        
            #If the user press the up key or space or w mario will move to the right (hold,period are paramaters so you can hold the key and mario will move)    
            if (pyxel.btnp(pyxel.KEY_UP))  or (pyxel.btnp(pyxel.KEY_SPACE)) or (pyxel.btnp(pyxel.KEY_W)):
                
                if (mario.initial_height[0]==False  and mario.y == mario.initial_height[1]) or mario.on_platform and not mario.already_jumped :
                    #If mario is on the floor we change to True and we take the initial height so mario starts to jump
                    mario.initial_height=[True,mario.y]
                    mario.on_platform=False
                    mario.movement("jump")
                    mario.already_jumped=True
            blocked_jump=False
            for j in range(len(object.blocks_list)):
                if Collision_template.minus_y_collision(self,mario.x,mario.y,object.blocks_list[j].x,object.blocks_list[j].y,object.blocks_list[j].name,power_ups,hud,object,j,object.blocks_list[j].alive,mario.super_mario):
                    blocked_jump=True

            #If mario is on the air , he will continue jumping until he reaches the maximum height of jump (logic on mario class)
            if mario.initial_height[0]==True and not blocked_jump:
                mario.movement("jump")
            else:
                mario.initial_height[0]=False
            #We check that if there is a collision or not, if there is a collision mario will not go down
            go_down=True
            for j in range(len(object.blocks_list)):
                if not Collision_template.y_collision(self,mario.x,mario.y,object.blocks_list[j].x,object.blocks_list[j].y,object.blocks_list[j].name,object.blocks_list[j].alive,mario.super_mario_size_mushroom):
                    go_down=False
            #If go down is true mario then will start going down
            if  go_down:
                mario.movement("down")
                mario.on_platform=True
            else:
                mario.initial_height=[False,mario.y]

            #If mario  on middle screen then we move all objects(not the parameter) to the left
            if mario.middle_screen:
                object.update_block_coordinates()
                enemies.update_coordinates_enemies(object)
                power_ups.update_coordinates(object)
                mario.middle_screen=False
                    