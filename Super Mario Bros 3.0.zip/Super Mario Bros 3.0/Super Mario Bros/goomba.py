from mushroom import Mushroom
class Goomba(Mushroom):
    """
    This class will be responsible to manage the object Goomba with inheritance of Mushroom (update coordinates,and setters,properties)
    """
    def __init__(self,x,y):
        self.x = float(x)
        self.y = float(y)
        self.sprite= (0,32,48,16,16)
        self.looking_right=False
        self.name = "goomba"
        self.alive = True