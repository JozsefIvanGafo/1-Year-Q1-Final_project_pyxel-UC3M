"""
Super mario bros game App class
description:
Here the program will create a class App that will execute the draw and update functions for the Main program
@Author: József Iván Gafo and Marcos González
@since 11/14/2021
@Version 1.0.0 
"""
import pyxel
from mario import Mario
from hud import Hud
from Objects import Objects
from enemies import Enemies
from mariocontrols import MarioControls
from power_ups import PowerUps


class App:
    """This class execute the draw and update functions"""
    def __init__(self,width:int,height:int) :
        """This are the parameters to create the screen
        @param width, it determines the width of the screen
        @param height, it determines the height of the screen
        """
        self.screen_width=width
        self.screen_height=height
        
        #We spawn a Mario on the screen (on the top down on the left)
        self.mario=Mario(0,self.screen_height-48,False)
        #We activate the different classes
        self.hud=Hud(0,0,333)
        self.objects=Objects()
        self.enemies=Enemies()
        self.controls=MarioControls()
        self.power_ups=PowerUps()
    #Here we will put the diferent controls for mario and ennemies
    def update(self):
        """
        This function will be executed every frame, the function is in charge of updating different events like the movement of mario, ennemies.
        """
        #Is to play the music
        if self.enemies.enemies_list[0].x == 150:
            self.play_music()
        #If we press the button escape the program will close
        if pyxel.btnp(pyxel.KEY_ESCAPE):
            pyxel.quit()
        if self.mario.mario_is_alive=="alive":
            #This method is to execute the controls of mario and avoid excessive code on app.py
            self.controls.controls_of_mario(self.mario,self.objects,self.enemies,self.power_ups,self.hud)
            self.power_ups.update_coordinates(self.objects)
            self.enemies.update_coordinates_enemies(self.objects)
            self.enemies.collision_with_mario(self.mario,self.hud)
            self.power_ups.collision_with_mario(self.mario,self.hud)
            

    def play_music(self):
        pyxel.playm(0,loop=True)
        
        

    #Here we declare the draw function, where it will do the graphics part
    def draw(self):
        #We project the tilemap on the screen (It needs to be first so it doesn't overwrite Mario)
        if self.mario.mario_is_alive=="alive":
            pyxel.bltm(0, 0, 0, 0, 0, 32, 32)
            
           #Here we print the decoration,blocks,pipes
            self.objects.print_blocks()
            
            #We spawn the enemies
            self.enemies.print_ennemies_on_the_screen()
            #change animation of mario if its jumping or not or if its big
            if self.mario.super_mario == False:
                #Mario jumping
                if (self.mario.initial_height[0] or self.mario.y != self.mario.initial_height[1]) and not( self.mario.on_platform and  not self.mario.already_jumped):
                    pyxel.blt(self.mario.x, self.mario.y, self.mario.sprite_jump[0],
                        self.mario.sprite_jump[1], self.mario.sprite_jump[2], self.mario.sprite_jump[3],
                        self.mario.sprite_jump[4],colkey=0)
                #Mario on the floor
                else:
                    pyxel.blt(self.mario.x, self.mario.y, self.mario.sprite[0],
                        self.mario.sprite[1], self.mario.sprite[2], self.mario.sprite[3],
                        self.mario.sprite[4],colkey=0)
                        
                        
                    
             #if mario is big           
            else:
                pyxel.blt(self.mario.x, self.mario.y, self.mario.super_mario_looking_right[0],
                        self.mario.super_mario_looking_right[1], self.mario.super_mario_looking_right[2], self.mario.super_mario_looking_right[3],
                        self.mario.super_mario_looking_right[4],colkey=0)

            #We print the mushrooms
            self.power_ups.print_mushroom_on_the_screen()
                        
            #Here we draw the timer starting from 256
            pyxel.text(self.screen_width-40,10,"TIME:"+str(int(self.hud.timer(self.mario))),7)
            #We print the hud on the screen (coins,score,name of MArio,and its position)
            pyxel.text(90,10,"Coins X "+str(int(self.hud.coins)),7)
            pyxel.text(10,10,"MARIO",7)
            pyxel.text(10,20,"score: "+str(int(self.hud.score)),7)
            pyxel.text(140,10,str(self.mario.x)+", "+str(self.mario.y),7)
            
        else:
            #If Mario is dead
            pyxel.cls(0)
            pyxel.text(70,110,"You are dead ",7)
            pyxel.text(70,120," press escape to exit the program",7)
            pyxel.text(70,130," thanks for playing Super Mario",7)
            