class Pipes:
    """
    This class will be responsible to manage the object Pipes with inheritance of Pipes 
    """
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.sprite= (0,32,0,32,32)
        self.name = "pipes"
        self.alive=True
    def update_coordinates(self):
        """
        This method is in charge to update x coordinates that will be activated when mario is on the middle of the screen
        """
        self.x-=2

    """setters and properties"""
    
    @property
    def x(self):
        return self.__x
    @x.setter
    def x(self,x):
        if type(x)!=(int or float):
            raise TypeError("The x of the block must be an integer")
        else:
            self.__x=x
    #We protect the y
    @property
    def y(self):
        return self.__y
    @y.setter
    def y(self,y):
        if type(y)!=(int or float):
            raise TypeError("The y of the block must be an integer")
        elif y<0 or y>258:
            raise ValueError("The y of the block must be bigger than 0 and smaller of 256")
        else:
            self.__y=y
    """
    @property
    def sprite(self):
        return self.__sprite
    

    @property
    def name(self):
        return self.__name"""

    @property
    def alive(self):
        return self.__alive

    @alive.setter
    def alive(self,new_value):
        if type(new_value)!=bool:
            raise TypeError("The y should be an boolean")
        else:
            self.__alive=new_value