from pipes import Pipes
class Bush(Pipes):
    """
    This class will be responsible to manage the object Bush with inheritance of Pipes (update coordinates)
    """
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.sprite = (0,16,88,48,16)
        self.name = "bush"
