"""
Super mario bros game hud class
description:
Here the program will create a class hud that will draw the lives, coins, score and time for the program
@Author: József Iván Gafo and Marcos González
@since 11/14/2021
@Version 0.0.1
"""
import pyxel
class Hud:
    """This class handle the score, the time, the coins counter and the lives"""
    def __init__(self,coins:int,score:int,time:int):
        self.coins = coins
        self.score = score
        self.time = float(time)
    
    def timer(self,mario):
        """This method defines the timer (countdown)"""
        actual_time= self.time-0.03
        if actual_time < 0:
            self.time = 0
            mario.mario_is_alive="dead"
        else:
            self.time=actual_time
        return self.time
    def coins_counter(self):
        self.coins+=1
    def score_increase(self,number):
        self.score += number

    """ propertyes and setters"""
    @property
    def coins(self):
        return self.__coins

    @coins.setter
    def coins(self,new_value):
        if type(new_value)!=int:
            raise TypeError("The y should be an int")
        else:
            self.__coins=new_value
    @property
    def score(self):
        return self.__coins

    @score.setter
    def score(self,new_value):
        if type(new_value)!=int:
            raise TypeError("The y should be an int")
        else:
            self.__score=new_value
    @property
    def time(self):
        return self.__time

    @time.setter
    def time(self,new_value):
        if type(new_value)!=float:
            raise TypeError("The y should be a float")
        else:
            self.__time=new_value