class Mushroom:
    """
    This class creates an object for Mushroom
    """
    def __init__(self,x,y):
        """
        Here we load the x,y spawn coordinates and we set some initial values
        """
        self.x = float(x)
        self.y = float(y)  
        self.sprite = (0,0,32,16,16)
        self.looking_right=False
        self.name="mushroom"
        self.alive=True
    def update_coordinates(self,go_down=False):
        """
        This method is in charge to update the coordinates
        @param go_down, has a default value False because we are only interested when it detecs that goes down
        """
        if self.looking_right:
            self.x += 0.04
        elif not self.looking_right:
            self.x -= 0.04
        if self.y<208 and go_down:
            self.y+=0.06
    #We are having some problems with setters and properties.
    
    @property
    def x(self):
        return self.__x
    @x.setter
    def x(self,x):
        if type(x)!=float:
            raise TypeError("The x of the entity must be an float")
        else:
            self.__x=x
    #We protect the y
    @property
    def y(self):
        return self.__y
    @y.setter
    def y(self,y):
        if type(y)!=float:
            raise TypeError("The y of the entity must be an float")
        elif y<0 or y>258:
            raise ValueError("The y of the entity must be bigger than 0 and smaller of 256")
        else:
            self.__y=y
    """
    @property
    def sprite(self):
        return self.__sprite"""
    @property
    def looking_right(self):
        return self.__looking_right
    @looking_right.setter
    def looking_right(self,new_value):
        if type(new_value)!=bool:
            raise TypeError("The y should be an boolean")
        else:
            self.__looking_right=new_value
    """
    @property
    def name(self):
        return self.__name"""
    @property
    def alive(self):
        return self.__alive
    @alive.setter
    def alive(self,new_value):
        if type(new_value)!=bool:
            raise TypeError("The y should be an boolean")
        else:
            self.__alive=new_value

