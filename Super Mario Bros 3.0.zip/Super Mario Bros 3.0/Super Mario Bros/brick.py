from pipes import Pipes
class Brick(Pipes):
    """
    This class will be responsible to manage the object Pipe with inheritance of Pipes (update coordinates)
    """
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.sprite=(0,0,16,16,16)
        self.name = "brick"
        self.alive=True
    def hitted(self):
        """
        This method is to activate that the object has been hitted
        """
        self.alive=False