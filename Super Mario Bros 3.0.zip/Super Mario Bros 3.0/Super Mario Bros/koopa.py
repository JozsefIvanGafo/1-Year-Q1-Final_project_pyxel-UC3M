from mushroom import Mushroom
class Koopa(Mushroom):
    """
    This class will be responsible to manage the object Koopa with inheritance of Mushroom (update coordinates,and setters,properties)
    """
    def __init__(self,x,y):
        self.x = float(x)
        self.y = float(y-8)
        self.sprite = (0,16,136,16,32)
        self.looking_right=False
        self.name = "koopa"
        self.alive = True
    