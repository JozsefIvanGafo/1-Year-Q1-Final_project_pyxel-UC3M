"""
Super mario bros game
description:
Here the program will execute the power ups.
@Author: József Iván Gafo and Marcos González
@since 11/14/2021
@Version 0.0.1
"""
from mushroom import Mushroom
import pyxel
import random
from collision_template import Collision_template
class PowerUps:
    """
    This class is in charge of managing the powerups like the mushroom and the generation of coins
    """
    def __init__(self):
        self.sprite_mushroom = (0,0,32,16,16)
        self.mushroom_list=[]
        
    def contact(self,hud:object,coordinates:list,object:object,j:int,is_mario_big:bool):
        """
        This method decides what will happend when mario touches a question block
        @param hud, we import information about the hud(specially to use to increase the score or the coin counter)
        @param coordinates, we use it to spawn the mushroom on the top of the question block
        @param objects, we import the object objects where we will change the status of question brick to empty brick
        @param j, the position on the list of the question block


        """
        random_number = random.randint(0,100)
        #we randomly select wheter to spawn a mushroom or a coin. If mario is already big it will increase the coin counter
        if random_number>=55 or is_mario_big:
            hud.coins_counter()
            hud.score_increase(500)
            print("coin earned")

        else:
            var1=[coordinates[0],coordinates[1]-16]
            #we take the coordinates to spawn  a mushroom
            self.mushroom_list.append(Mushroom(var1[0],var1[1]))
            hud.score_increase(750)
        #We change the status of the question block
        object.blocks_list[j].hitted()

    def update_coordinates(self,object):
        """
        This method is in charge to update the coordinates of the mushroom and also checking the collisions
        """
        for i in range(len(object.blocks_list)):
            for j in range(len(self.mushroom_list)):
                if (not Collision_template.x_collision(self,self.mushroom_list[j].x,self.mushroom_list[j].y,
                object.blocks_list[i].x,object.blocks_list[i].y,self.mushroom_list[j].looking_right,object.blocks_list[i].name,object.blocks_list[j].alive)):
                    self.mushroom_list[j].looking_right= not self.mushroom_list[j].looking_right
                go_down=False
                if Collision_template.y_collision(self,self.mushroom_list[j].x,self.mushroom_list[j].y,
                object.blocks_list[i].x,object.blocks_list[i].y,object.blocks_list[i].name,object.blocks_list[j].alive):
                    go_down=True
                self.mushroom_list[j].update_coordinates(go_down)

    def collision_with_mario(self,mario,hud):
        """
        This method checks if mario touches a mushroom
        """
        for j in range(len(self.mushroom_list)):
            detected=(Collision_template.mario_collision_with_entity(self,mario.x,mario.y,self.mushroom_list[j].x,self.mushroom_list[j].y,self.mushroom_list[j].alive,-mario.super_mario_size_mushroom))
            if detected:
                mario.super_mario = True
                hud.score_increase(1500)
                mario.super_mario_size_mushroom=16
                self.mushroom_list[j].alive=False

    def print_mushroom_on_the_screen(self):
        """
        It prints the mushrooms on the screen
        """
        for j in range(len(self.mushroom_list)):
            if  self.mushroom_list[j].x>=-32 and self.mushroom_list[j].alive:
                pyxel.blt(self.mushroom_list[j].x, self.mushroom_list[j].y, self.mushroom_list[j].sprite[0],
                    self.mushroom_list[j].sprite[1], self.mushroom_list[j].sprite[2], self.mushroom_list[j].sprite[3],
                    self.mushroom_list[j].sprite[4],colkey=0)

      



            