from pipes import Pipes
class Clouds(Pipes):
    """
    This class will be responsible to manage the object Clouds with inheritance of Pipes (update coordinates)
    """
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.sprite = (0,16,64,48,24)
        self.name = "clouds"