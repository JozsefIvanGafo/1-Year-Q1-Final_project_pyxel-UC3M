"""
Super mario bros game
description:
This class is a template for the collisions that will use a lot of entities
@Author: József Iván Gafo and Marcos González
@since 11/14/2021
@Version 1.5.6
"""
class Collision_template:
    """
    In this class we will put the templates of different functions of collision on the x axis or on the y axis or if mario hit a mushroom or an enemy
    Primary use: Avoid code repetition
    """
    def x_collision(self,x:int,y:int,x_block:int,y_block:int,looking_right:bool,name:str,alive,extrasize:int=0)->bool:
        """
        This function will determine if there is a collision on front or not
        @param x, we import the x coordinate of the entitie (mario or enemy)
        @param y, we import the y coordinate of the entitie (mario or enemy)
        @param x_block, is the x coordinate of an object of a block
        @param y_block, is the y coordinate of an object of a block
        @param looking_right, it tells us if is looking right or left
        @param name, is the name of the object
        @param extrasize , is to add extra numbers (an extra height), e.g when Mario is on Big Mario, default value 0
        """
        
        can_movement=True
        #If there is a collision on front
        if looking_right:
            
            #If there is a pipe in front (16*16)
            if name=="pipes":
                if x >= (x_block-16)  and x <= (x_block+32) and y+extrasize >= y_block:
                    can_movement =False
            #If there is a blocks 16*16 in front
            else:
                if ((x >= x_block-12) and x <= (x_block) and y + extrasize >=y_block and y + extrasize <= y_block + 16) and alive:
                    can_movement =False
              
        #If there is a collision on the back of mario
        elif not looking_right:
            
            #If there is a pipe behind
            if name=="pipes":
                if (x <= (x_block+34)and x >= (x_block-14)
                    and y + extrasize >= y_block and alive):
                    can_movement =False

            #If there is a block behind
            else:   
                if (x <= (x_block+16) and x >= (x_block) 
                and y + extrasize >= y_block and y + extrasize <= y_block + 16) and alive:
                    can_movement=False

       
        #Return if it can move or not
        return  can_movement

    def y_collision(self,x:int,y:int,x_block:int,y_block:int,name:str,alive,extrasize:int=0)->bool:
        """
        This function will determine if there is a collision bellow mario
        @param x, we import the x coordinate of the entitie (mario or enemy)
        @param y, we import the y coordinate of the entitie (mario or enemy)
        @param x_block, is the x coordinate of an object of a block
        @param y_block, is the y coordinate of an object of a block
        @param looking_right, it tells us if is looking right or left
        @param name, is the name of the object
        @param extrasize , is to add extra numbers (an extra height), e.g when Mario is on Big Mario, default value 0
        """
        #colisions for the top
        go_down=True
        #If under mario is a pipe
        if name == "pipes":
            if x >= (x_block-16) and x <= (x_block+32) and y >= ((y_block-16)-extrasize):
                go_down =False
                
        #if under mario are bricks
        else:
            if x >= (x_block-14) and x <= (x_block+14) and y >= ((y_block-16)-extrasize) and y < y_block+3 and alive:
                go_down =False
          
        return go_down

    def minus_y_collision(self,x:int,y:int,x_block:int,y_block:int,name:str,power_ups,hud,object,j,alive:bool,is_mario_big:bool)->bool: 
        """
        This function will determine if there is a collision above mario
        @param x, we import the x coordinate of the entity mario
        @param y, we import the y coordinate of the entity mario
        @param x_block, is the x coordinate of an object of a block
        @param y_block, is the y coordinate of an object of a block
        @param name, is the name of the object
        @param power_ups, to import information about the power_ups, e.g when we hit a question block from below, it spawns a mushroom or coin
        @param hud, we increase the score when the block is hitted
        @param object we import information from app that is related with objects
        @param j, is the position of the block that is looking for
        @param alive, is to check that the block is destroyed or not
        @param extrasize , is to add extra numbers (an extra height), e.g when Mario is on Big Mario, default value 0
        @param is_mario_big, is wheter to power_up.contact will spawn a coin or a mushroom
        """ 
        blocked_jump = False
            #We check that if is below a question brick 
        if name == "question block":
            if x >= (x_block-14) and x <= (x_block+14) and y <= (y_block+14) and y >= (y_block) and alive:
                blocked_jump =True
                var1 = [x_block,y_block]
                #We use this function to generate a coin or a msuhroom
                power_ups.contact(hud,var1,object,j,is_mario_big)
        #Since the pipe will not go under it we put this if to only include blocks    
        elif name !="pipe":
            if x >= (x_block) and x <= (x_block+14) and y <= (y_block+14) and y>= (y_block) and alive:
                blocked_jump =True
                hud.score_increase(100)
                #We activate this function where we make disapear the block
                object.blocks_list[j].hitted()
        #We return the result
        return blocked_jump

    def mario_collision_with_entity(self,x,y,x_entity,y_entity,alive,extrasize):   
        """
        This function will determine if there is a collision above mario
        @param x, we import the x coordinate of the entity mario
        @param y, we import the y coordinate of the entity mario
        @param x_entity, is the x coordinate of an object of an enemy
        @param y_entity, is the y coordinate of an object of an enemy
        @param alive, is to check that the netity is alive
        @param extrasize , is to add extra numbers (an extra height), e.g when Mario is on Big Mario, default value 0
        
        """      
        detected=False
        if x >= (x_entity-18) and x <= (x_entity+8) and y+extrasize >= (y_entity) and y + extrasize <= y_entity+16 and alive:
            detected=True
        return detected
    
                        
    def mario_y_collision_with_entity(self,x,y,x_entity,y_entity,alive,extrasize=0):
        """
        This function will determine if mario kills the ennemy
        @param x, we import the x coordinate of the entitie mario 
        @param y, we import the y coordinate of the entitie mario 
        @param x_entity, is the x coordinate of an entity
        @param y_entity, is the y coordinate of an entity
        @param alive, is to determine wheter the entity is alive or not
        @param extrasize , is to add extra numbers (an extra height), e.g when Mario is on Big Mario, default value 0
        """ 
        detected=False
        if x >= (x_entity-18) and x <= (x_entity+8) and y+extrasize == (y_entity-16) and y+extrasize < y_entity-2 and alive:
            detected=True
        return detected
        
            