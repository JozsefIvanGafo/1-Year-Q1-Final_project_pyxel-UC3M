"""
Super mario bros game
description:
Here the program will execute the power ups.
@Author: József Iván Gafo and Marcos González
@since 11/14/2021
@Version 0.0.1
"""
from mushroom import Mushroom
import pyxel
import random
import pyxel
from Objects import Objects
from collision_template import Collision_template
class PowerUps:
    def __init__(self):
        self.sprite_mushroom = (0,0,32,16,16)
        self.mushroom_list=[]
        
    def contact(self,hud,coordinates,object,j):
        random_number = random.randint(0,100)
        #we increase the coin counter by 1
        if random_number<=0:#55:
            hud.coins_counter()
            hud.score_increase(500)
            print("coin earned")
            hud.coin_time_spawn_when_the_block_is_hit = hud.time-0.5
            hud.coin_coordinates_when_the_block_is_hit=[coordinates[0],coordinates[1]]

        else:
            var1=[coordinates[0],coordinates[1]-16]
            #we take the coordinates to spawn  a mushroom
            self.mushroom_list.append(Mushroom(var1[0],var1[1]))
            hud.score_increase(750)
        #We change the status of the question block
        object.blocks_list[j].hitted()

    def update_coordinates(self,object):
         for i in range(len(object.blocks_list)):
            for j in range(len(self.mushroom_list)):
                if (not Collision_template.x_collision(self,self.mushroom_list[j].x,self.mushroom_list[j].y,
                object.blocks_list[i].x,object.blocks_list[i].y,self.mushroom_list[j].looking_right,object.blocks_list[i].name,object.blocks_list[j].alive)):
                    self.mushroom_list[j].looking_right= not self.mushroom_list[j].looking_right
                go_down=False
                if Collision_template.y_collision(self,self.mushroom_list[j].x,self.mushroom_list[j].y,
                object.blocks_list[i].x,object.blocks_list[i].y,object.blocks_list[i].name,object.blocks_list[j].alive):
                    go_down=True
                self.mushroom_list[j].update_coordinates(go_down)

    def collision_with_mario(self,mario,hud):
        for j in range(len(self.mushroom_list)):
            detected=(Collision_template.mario_collision_with_entity(self,mario.x,mario.y,self.mushroom_list[j].x,self.mushroom_list[j].y,self.mushroom_list[j].alive,mario.super_mario_size_mushroom))
            if detected:
                mario.super_mario = True
                hud.score_increase(1500)
                mario.super_mario_size_mushroom=16
                self.mushroom_list[j].alive=False

    def print_mushroom_on_the_screen(self):
        for j in range(len(self.mushroom_list)):
            #288= 256(the screen)+32 (so it doesn't spawn all the ennemies and we free some memory)
            if  self.mushroom_list[j].x>=-32 and self.mushroom_list[j].alive:
                pyxel.blt(self.mushroom_list[j].x, self.mushroom_list[j].y, self.mushroom_list[j].sprite[0],
                    self.mushroom_list[j].sprite[1], self.mushroom_list[j].sprite[2], self.mushroom_list[j].sprite[3],
                    self.mushroom_list[j].sprite[4],colkey=0)

      



            