"""
Super mario bros game
description:
Here the program will create the class Mario that will be in charge of all the things related to mario
@Author: József Iván Gafo and Marcos González
@since 11/14/2021
@Version 0.0.1
"""
import pyxel
class Mario:
    """This class stores all the information about the entetie of Mario"""
    def __init__(self,x:int,y:int,middle_of_the_screen:bool):
        """This method creates/spawns mario on such coordinates
        @param x the starting x pos of Mario
        @param y the starting y pos of Mario
        @param looking_right is a bool that indicates that mario 
        is looking right (True/False)
        @param  middle_of_the screen 
        """
        #We define the position of where to spwan Mario
        self.x=x
        self.y=y 
        self.middle_screen=middle_of_the_screen
        self.mario_is_alive="alive"
        self.super_mario=False
        self.super_mario_size_mushroom=0
        #When mario lose super mario and don't die instantly
        self.god_mode=999999999999999
        #we add some size when mario picks a mushroom to modify the coordinates
        #self.super_mario_extra_size=0
        
        #Here we define the sprite of Mario (bank,x pos on the bank, y pos on the bank, size height x base)
        self.sprite=(0,0,48,16,16)
        self.sprite_jump =(0,0,120,16,16)
        self.super_mario_looking_right = (0,0,176,16,32)
        self.super_mario_looking_left = (0,16,176,16,32)
        #self.super_mario.jump.sprite =()

        #The course that mario will travel (This attribute will be used to substractthe x on Objects)
        #self.course=0
        #Attributes used for taking coordinates for the jump
        #initial_height[0]==True means that mario is going up and  False means that is either going down or is on the floor
        self.initial_height=[False,y]
        #the floor isn't a platform
        #on_platform means that is on a platform
        self.on_platform=False
        #already_jumped means that mario is on the air
        #difference between already jumped and initial_height[0] i that already_jumped is mario on the air and the initialheight[0] is that mario is going up
        self.already_jumped=False

    #We define the basic movement for mario(Do not forget to later put a parameter for the size of mushroom)
    def movement(self,direction:str):
        """
        This method defines the movement of mario
        @param direction is where mario will move next
        """
        
        #To check that the values are correct
        if direction.lower() in ("right","left","jump","down"):

            #Where the order is receive mario moves to the right (x+2)
            if direction.lower()=="right":
                #MArio moves to the right until the middle of the screen
                if self.x<112:
                    self.x=self.x+2
                #When mario is on the center mario stop to move and middle of the screen 
                # is true and we add to course +2 that we will substract to objects
                else:
                    self.middle_screen=True
                    #self.course+=2
                
                
            #Where mmario receives the order to move to the right (x-2)
            elif direction.lower()=="left":
                if self.x <=0:
                    self.x = 0
                else:
                    self.x=self.x-2

            #Where the order is receive mario moves to the right (y-2)
            if direction.lower()=="jump":
                if self.y > (self.initial_height[1] - 64):
                    self.y -= 8
                elif self.y<=(self.initial_height[1] - 64):
                    self.initial_height[0]=False
                    
            #Where mmario receives the order to move to the right (y+2)
            elif direction.lower()=="down":
                if self.y >= 208 and not self.super_mario:
                    #Coordinates of the floor
                    self.y = 208
                    #We change the object of mario of already_jumped to false so it can jump
                    self.already_jumped=False
                elif self.y >= 208-16 and  self.super_mario:
                    #Coordinates of the floor
                    self.y = 208-16
                    #We change the object of mario of already_jumped to false so it can jump
                    self.already_jumped=False
                else:
                    self.y=self.y+4

        #Else we raise an error and we close the program
        else:
            raise ValueError("To use the direction fun. of Mario the direction must be right or left or jump or down, check if you misspelled in your program using this function")


    #Here we will protect our code from mistakes
    #We protect the x
    @property
    def x(self):
        return self.__x
    @x.setter
    def x(self,x):
        if type(x)!=int:
            raise TypeError("The x of mario must be an integer")
        elif x<0 or x>126:
            raise ValueError("The x of mario must be bigger than 0 and smaller of 128")
        else:
            self.__x=x
    #We protect the y
    @property
    def y(self):
        return self.__y
    @y.setter
    def y(self,y):
        if type(y)!=int:
            raise TypeError("The y of mario must be an integer")
        elif y<0 or y>258:
            raise ValueError("The y of mario must be bigger than 0 and smaller of 256")
        else:
            self.__y=y
    #Here we will protect the sprites
    """
    @property
    def sprite(self):
        return self.__sprite
    @property
    def sprite_jump(self):
        return self.__sprite_jump
    """



    #self.sprite=(0,0,48,16,16)
     #   self.sprite_jump =(0,0,120,16,16)