from mushroom import Mushroom
class Koopa(Mushroom):
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.sprite = (0,16,136,16,32)
        self.looking_right=False
        self.name = "koopa"
        self.alive = True
    @property
    def x(self):
        return self.__X
    @x.setter
    def x(self,x):
        if type(x) != int:
            raise TypeError("Sorry, this value must be an integer")
        elif x < 0 or x > 132:
            raise ValueError("Sorry, the value must be over 0")
        else:
            self.__x = x
    @property
    def y(self):
        return self.__y
    @y.setter
    def y(self,y):
        if type(y) != int:
            raise TypeError("Sorry, this value must be an integer")
        elif y < 0 or y > 132:
            raise ValueError("Sorry, the value must be over 0")
        else:
            self.__y = y