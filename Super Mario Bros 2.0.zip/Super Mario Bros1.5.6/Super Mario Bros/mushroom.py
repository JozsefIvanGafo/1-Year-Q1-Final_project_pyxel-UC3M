class Mushroom:
    def __init__(self,x,y):
        self.x = x
        self.y = y  
        self.sprite = (0,0,32,16,16)
        self.looking_right=False
        self.name="mushroom"
        self.alive=True
    def update_coordinates(self,go_down=False):
        if self.looking_right:
            self.x += 0.04
        elif not self.looking_right:
            self.x -= 0.04
        if self.y<208 and go_down:
            self.y+=0.06
    @property
    def x(self):
        return self.__X
    @x.setter
    def x(self,x):
        if type(x) != int:
            raise TypeError("Sorry, this value must be an integer")
        elif x < 0 or x > 132:
            raise ValueError("Sorry, the value must be over 0")
        else:
            self.__x = x
    @property
    def y(self):
        return self.__y
    @y.setter
    def y(self,y):
        if type(y) != int:
            raise TypeError("Sorry, this value must be an integer")
        elif y < 0 or y > 132:
            raise ValueError("Sorry, the value must be over 0")
        else:
            self.__y = y