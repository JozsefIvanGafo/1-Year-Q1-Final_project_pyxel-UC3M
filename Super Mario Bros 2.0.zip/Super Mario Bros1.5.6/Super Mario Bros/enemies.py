"""
Super mario bros game
description:
Here the program will create the class enemies to spawn all the enemies
@Author: József Iván Gafo and Marcos González
@since 11/14/2021
@Version 0.0.1
"""
from mario import Mario
import random
import pyxel
from koopa import Koopa
from goomba import Goomba
from collision_template import Collision_template
class Enemies:
    def __init__(self):
        #spawnrate koopa(25%) and goomba(75%)
        self.spawn_list = [25,75]
        #Max of ennemies
        self.max_enemies=4
        self.enemies_on_screen=0
        x_spawn_cord=[150,300,450,750,1000]
        y_spawn_cord=[208 for i in range(len(x_spawn_cord))]
        self.enemies_list=[]
        for i in range(len(x_spawn_cord)):
            #We load what type of ennemy will spawn on each spawn coordinates
            random_number = random.randint(1,100)
            if random_number<self.spawn_list[0]:
                self.enemies_list.append(Goomba(x_spawn_cord[i],y_spawn_cord[i]))

            else:
                self.enemies_list.append(Koopa(x_spawn_cord[i],y_spawn_cord[i]-8))

    def update_coordinates_enemies(self,object):
        
        for j in range(len(self.enemies_list)):
            
            for i in range(len(object.blocks_list)):
                

                #self.enemies_list[j].looking_right= 
                if (not Collision_template.x_collision(self,self.enemies_list[j].x,self.enemies_list[j].y,
                object.blocks_list[i].x,object.blocks_list[i].y,self.enemies_list[j].looking_right,object.blocks_list[i].name,object.blocks_list[j].alive)):
                    self.enemies_list[j].looking_right=not self.enemies_list[j].looking_right
                self.enemies_list[j].update_coordinates()
    
    def collision_with_mario(self,mario,hud):
        for j in range(len(self.enemies_list)):
            y_detected=Collision_template.mario_y_collision_with_entity(self,mario.x,mario.y,self.enemies_list[j].x,self.enemies_list[j].y,self.enemies_list[j].alive,mario.super_mario_size_mushroom)
            if y_detected:
                if mario.god_mode>hud.time:  
                    print("The enemy is dead")
                    hud.score_increase(1000)
                    self.enemies_list[j].alive=False
            else:
                detected=(Collision_template.mario_collision_with_entity(self,mario.x,mario.y,self.enemies_list[j].x,self.enemies_list[j].y,self.enemies_list[j].alive,mario.super_mario_size_mushroom))
                if detected:
                    if mario.super_mario_size_mushroom>0:
                        mario.super_mario=False
                        mario.super_mario_size_mushroom=0
                        mario.god_mode=hud.time-3
                    #To check that mario is not invencible after loosing the mushroom
                    else: 
                        if mario.god_mode>hud.time:
                            print("dead from the right")
                            mario.mario_is_alive="dead"
                    
        


    def print_ennemies_on_the_screen(self):
        for j in range(len(self.enemies_list)):
            if  self.enemies_list[j].x>=-32 and self.enemies_list[j].alive:

                pyxel.blt(self.enemies_list[j].x, self.enemies_list[j].y, self.enemies_list[j].sprite[0],
                    self.enemies_list[j].sprite[1], self.enemies_list[j].sprite[2], self.enemies_list[j].sprite[3],
                    self.enemies_list[j].sprite[4],colkey=12)
    