class Pipes:
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.sprite = (0,32,0,32,32)
        self.name = "pipes"
        self.alive=True
    def update_coordinates(self):
        self.x-=2
    @property
    def x(self):
        return self.__X
    @x.setter
    def x(self,x):
        if type(x) != int:
            raise TypeError("Sorry, this value must be an integer")
        elif x < 0 or x > 132:
            raise ValueError("Sorry, the value must be over 0")
        else:
            self.__x = x
    @property
    def y(self):
        return self.__y
    @y.setter
    def y(self,y):
        if type(y) != int:
            raise TypeError("Sorry, this value must be an integer")
        elif y < 0 or y > 132:
            raise ValueError("Sorry, the value must be over 0")
        else:
            self.__y = y