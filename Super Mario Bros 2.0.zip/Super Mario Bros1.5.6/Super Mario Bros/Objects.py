"""
Super mario bros game
description:
Here the program will create the class objects to create all the objects such as pipes, blocks etc.
@Author: József Iván Gafo and Marcos González
@since 11/14/2021
@Version 0.0.1
"""
import pyxel
from pipes import Pipes
from bush import Bush
from clouds import Clouds
from brick import Brick
from question_block import Question_block

class Objects:
    def __init__(self) :
        self.blocks_list=[]
        self.decoration_list=[]
        #Here we put variables for the x and y for breakable bricks
        x_normal_brick=[128,160,398,416,416,432,432,432,432,544,640,640,640,640,656,656,656,672,672,688,932,948,964,1156,1156,1156,1156,1156,1156,1156,1156,1156,1156,1156,1156,1156,1156]
        y_normal_brick=[176,176,208,192,208,176,192,176,208,176,208,192,176,160,208,192,176,208,192,208,144,144,144,208,192,176,160,144,128,112,96,80,64,48,32,16,0]
        
        #self.normal_brick_list = []
        for i in range(len(x_normal_brick)):
            self.blocks_list.append(Brick(x_normal_brick[i],y_normal_brick[i]))

        #Here we put the x and y for the question bricks
        x_question_brick=[144,144,352,544,640]
        y_question_brick=[128,176,160,96,80]

        #self.question_brick_list = []
        for i in range(len(x_question_brick)):
            self.blocks_list.append(Question_block(x_question_brick[i],y_question_brick[i]))

        #Here we put the x and y for the clouds
        x_cloud=[15,70,120,170,240,300,370,430,500,600,700,800,900,1000]
        y_cloud=[15,60,2,40,24,55,20,60,34,96,112,34,20,60]
        
        #self.cloud_list = []
        for i in range(len(x_cloud)):
            self.decoration_list.append(Clouds(x_cloud[i],y_cloud[i]))

        #Here we put the x and y for the bushes
        x_bush=[20,170,330,400,500,570,640,700,800,900,1000,1100]
        y_bush=[208,208,208,208,208,208,208,208,208,208,208,208]
        
        #self.bush_list = []
        for i in range(len(x_bush)):
            self.decoration_list.append(Bush(x_bush[i],y_bush[i]))

        #Here we put the x and y for the pipes
        
        x_pipe=[64,288,608,496,800,896]
        y_pipe=[192,192,192,192,192,192,192]
        
       
        for i in range(len(x_pipe)):
            self.blocks_list.append(Pipes(x_pipe[i],y_pipe[i]))

    def update_block_coordinates(self):
        for i in range(len(self.blocks_list)):
            self.blocks_list[i].update_coordinates()
        for i in range(len(self.decoration_list)):
            self.decoration_list[i].update_coordinates()
    def print_blocks(self):
        
        for j in range(len(self.decoration_list)):
            pyxel.blt(self.decoration_list[j].x, self.decoration_list[j].y, self.decoration_list[j].sprite[0],
                    self.decoration_list[j].sprite[1], self.decoration_list[j].sprite[2], self.decoration_list[j].sprite[3],
                    self.decoration_list[j].sprite[4],colkey=12)
       
        for j in range(len(self.blocks_list)):
             if self.blocks_list[j].alive:
                pyxel.blt(self.blocks_list[j].x, self.blocks_list[j].y, self.blocks_list[j].sprite[0],
                        self.blocks_list[j].sprite[1], self.blocks_list[j].sprite[2], self.blocks_list[j].sprite[3],
                        self.blocks_list[j].sprite[4],colkey=12)
            