"""
Super mario bros game
description:
Here the program will execute the power ups.
@Author: József Iván Gafo and Marcos González
@since 11/14/2021
@Version 0.0.1
"""
import time
import pyxel
import random
import pyxel
from Objects import Objects
class PowerUps:
    def __init__(self):
        self.sprite_mushroom = (0,0,32,16,16)
        self.coordinates_list_mushroom=[]
        self.mushroom_looking_right=[]
        
        
    def contact(self,hud,coordinates):
        random_number = random.randint(0,100)
        #we increase the coin counter by 1
        if random_number>=55:
            hud.coins_counter()
            hud.score_increase(500)
            print("coin earned")
            hud.coin_time_spawn_when_the_block_is_hit = hud.time-0.5
            #var1=[coordinates[0],coordinates[1]-16]
            hud.coin_coordinates_when_the_block_is_hit=[coordinates[0],coordinates[1]-16]

        else:
            #we take the coordinates to spawn  a mushroom
            self.coordinates_list_mushroom.append(coordinates)
            self.mushroom_looking_right.append(True)
            

            hud.score_increase(750)
    def print_mushrooms(self):
        for i in range(len(self.coordinates_list_mushroom)):
            pyxel.blt(self.coordinates_list_mushroom[i][0], self.coordinates_list_mushroom[i][1]-16, self.sprite_mushroom[0],
            self.sprite_mushroom[1], self.sprite_mushroom[2], self.sprite_mushroom[3],
            self.sprite_mushroom[4],colkey=0)
            
    def mushroom_movement_with_gravity(self,i:int,go_down:bool=False):

        if self.mushroom_looking_right[i]==True:
            self.coordinates_list_mushroom[i][0]+=2
        elif self.mushroom_looking_right[i]==False:
            self.coordinates_list_mushroom[i][0]-=2
        if self.coordinates_list_mushroom[i][1]<208+16 and go_down:
            self.coordinates_list_mushroom[i][1]+=2
            
    def collision_of_mushroom_with_objects(self,objects:object):
        for i in range(len(self.coordinates_list_mushroom)):
            #For x coordinates collision
            if self.mushroom_looking_right[i]:
                for j in range(objects.max):
                    #If there is a pipe in front
                    if j<len(objects.pipe_list):
                        if (self.coordinates_list_mushroom[i][0]) >= (objects.pipe_list[j][0]-16) and self.coordinates_list_mushroom[i][0] <= (objects.pipe_list[j][0]+32)and self.coordinates_list_mushroom[i][1] >= objects.pipe_list[j][1]:
                            self.mushroom_looking_right[i]=False
                         
                    #If there is a normal block in front
                    if j<len(objects.normal_brick_list):   
                        if self.coordinates_list_mushroom[i][0] >= (objects.normal_brick_list[j][0]-16) and self.coordinates_list_mushroom[i][0] <= (objects.normal_brick_list[j][0])and self.coordinates_list_mushroom[i][1] >=objects.normal_brick_list[j][1]+2 and self.coordinates_list_mushroom[i][1] <= objects.normal_brick_list[j][1]+16:   
                            self.mushroom_looking_right[i]=False
                          
                    #If there is a question brick in front
                    if j<len(objects.question_brick_list):   
                        if self.coordinates_list_mushroom[i][0] >= (objects.question_brick_list[j][0]-16) and self.coordinates_list_mushroom[i][0] <= (objects.question_brick_list[j][0])and self.coordinates_list_mushroom[i][1] >= objects.question_brick_list[j][1]+2 and self.coordinates_list_mushroom[i][1] <= objects.question_brick_list[j][1]+16:
                            self.mushroom_looking_right[i]=False
                           
            #If not looking right
            else:
                
                for j in range(objects.max):
                    #If there is a pipe behind
                    if j<len(objects.pipe_list):
                        if self.coordinates_list_mushroom[i][0] <= (objects.pipe_list[j][0]+34) and self.coordinates_list_mushroom[i][0] >= (objects.pipe_list[j][0]-14) and self.coordinates_list_mushroom[i][1] >= objects.pipe_list[j][1]:
                            self.mushroom_looking_right[i]=True
                    #If there is a normal block behind
                    if j<len(objects.normal_brick_list):   
                        if self.coordinates_list_mushroom[i][0] <= (objects.normal_brick_list[j][0]+18) and self.coordinates_list_mushroom[i][0] >= (objects.normal_brick_list[j][0]) and self.coordinates_list_mushroom[i][1] >= objects.normal_brick_list[j][1]+2 and self.coordinates_list_mushroom[i][1] <= objects.normal_brick_list[j][1]+16:
                            self.mushroom_looking_right[i]=True
                    #IF there is a question brick behind
                    if j<len(objects.question_brick_list):   
                        if self.coordinates_list_mushroom[i][0] <= (objects.question_brick_list[j][0]+18) and self.coordinates_list_mushroom[i][0] >= (objects.question_brick_list[j][0]) and self.coordinates_list_mushroom[i][1] >= objects.question_brick_list[j][1]+2 and self.coordinates_list_mushroom[i][1] <= objects.question_brick_list[j][1]+16:
                            self.mushroom_looking_right[i]=True
                            
            #For y coordinates collision
            go_down=True
            for j in range(objects.max):
                if j<len(objects.pipe_list):
                    if self.coordinates_list_mushroom[i][0] >= (objects.pipe_list[j][0]-16) and self.coordinates_list_mushroom[i][0] <= (objects.pipe_list[j][0]+32) and self.coordinates_list_mushroom[i][1] >= (objects.pipe_list[j][1]-16):
                        go_down =False
                #We check that if is above a normal brick
                if j<len(objects.normal_brick_list):
                    if self.coordinates_list_mushroom[i][0] >= (objects.normal_brick_list[j][0]-14) and self.coordinates_list_mushroom[i][0] <= (objects.normal_brick_list[j][0]+14) and self.coordinates_list_mushroom[i][1] >= (objects.normal_brick_list[j][1]-16) and self.coordinates_list_mushroom[i][1] < objects.normal_brick_list[j][1]+3:
                        go_down =False
                #We check that if is above a question brick 
                if j<len(objects.question_brick_list):
                    if self.coordinates_list_mushroom[i][0] >= (objects.question_brick_list[j][0]-14) and self.coordinates_list_mushroom[i][0] <= (objects.question_brick_list[j][0]+14) and self.coordinates_list_mushroom[i][1] >= (objects.question_brick_list[j][1]-16) and self.coordinates_list_mushroom[i][1] < objects.question_brick_list[j][1]+3:
                        go_down =False

                if j<len(objects.empty_block):
                    if self.coordinates_list_mushroom[i][0] >= (objects.empty_block[j][0]-14) and self.coordinates_list_mushroom[i][0] <= (objects.empty_block[j][0]+14) and self.coordinates_list_mushroom[i][1] >= (objects.empty_block[j][1]-16) and self.coordinates_list_mushroom[i][1] < objects.empty_block[j][1]+3:
                        go_down =False      
            self.mushroom_movement_with_gravity(i,go_down)
            
    def mario_collision_with_mushroom(self,mario,hud):
        we_can_delete=False
        for i in range(len(self.coordinates_list_mushroom)):  
                if mario.x >= (self.coordinates_list_mushroom[i][0]-18) and mario.x <= (self.coordinates_list_mushroom[i][0]+8) and mario.y+mario.super_mario_size_mushroom == (self.coordinates_list_mushroom[i][1]-16) and mario.y+mario.super_mario_size_mushroom < self.coordinates_list_mushroom[i][1]-2:
                    print("detected")
                    
                    mario.super_mario = True
                    hud.score_increase(1500)
                    we_can_delete=True
                    a=i
                    mario.super_mario_size_mushroom=16

        if we_can_delete:
            del self.coordinates_list_mushroom[a]  
            del self.mushroom_looking_right[a]          

      



            