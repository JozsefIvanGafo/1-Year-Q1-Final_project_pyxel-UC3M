"""
Super mario bros game
description:
Here the program will create the class enemies to spawn all the enemies
@Author: József Iván Gafo and Marcos González
@since 11/14/2021
@Version 0.0.1
"""
from mario import Mario
import random
import pyxel
class Enemies:
    def __init__(self):
        #bank, coord on the bank x, y and the size mxn
        self.sprite_goomba= (0,32,48,16,16)
        self.sprite_koopa = (0,16,136,16,32)
        #spawnrate koopa(25%) and goomba(75%)
        self.spawn_list = [25,75]
        #Max of ennemies
        self.max_ennemies=4
        self.ennemies_on_screen=0
        

        x_spawn_cord=[150,300,450,600,750,1000]
        y_spawn_cord=[208 for i in range(len(x_spawn_cord))]
        self.looking_right=[False for i in range(len(x_spawn_cord))]
        self.type_enemies_spawned_list=[]
        self.spawn_coordinates=[]
        for i in range(len(x_spawn_cord)):
            #We pack all the cordinates on a nested tuple
            ennemies_small_list=[x_spawn_cord[i],y_spawn_cord[i]]
            self.spawn_coordinates.append(ennemies_small_list)

            #We load what type of ennemy will spawn on each spawn coordinates
            random_number = random.randint(1,100)
            if random_number>self.spawn_list[0]:
                self.type_enemies_spawned_list.append("goomba")

            else:
                self.type_enemies_spawned_list.append("koopa")
        
        


    def update_coordinates_for_ennemies(self,can_movement,i):
        """
        Function that is in charge of updating the coordinates of the ennemies coordinates and to free the memory if necessary
        """
        
            #If the ennemy is looking left and can move
        if not self.looking_right[i] and can_movement:
            self.spawn_coordinates[i][0]-=2
            #If is looking left but cannot move (because of a collision) so it changes direction (and not can_movement)    
        elif not self.looking_right[i] :
            self.looking_right[i]=True
            self.spawn_coordinates[i][0]+=2
            #If the ennemy is looking right and can move
        elif self.looking_right[i] and can_movement:
            self.spawn_coordinates[i][0]+=2
            #Else the ennemy is looking right and cannot move(because of a collision) so it changes direction
        else:
            self.looking_right[i]=False
            self.spawn_coordinates[i][0]-=2
            
            """
            if self.spawn_coordinates[i][0]<=-32:
                del self.spawn_coordinates[i] 
                del self.enemies_spawned_list[i]"""
    

    def print_ennemies_on_the_screen(self):
        for i in range(len(self.spawn_coordinates)):
            #288= 256(the screen)+32 (so it doesn't spawn all the ennemies and we free some memory)
            if (self.spawn_coordinates[i][0] <=288 or self.spawn_coordinates[i][0]>=-32)and self.ennemies_on_screen<=self.max_ennemies:
                self.spawn_coordinates[i][0]-=1
                if self.type_enemies_spawned_list[i]=="goomba":
                    pyxel.blt(self.spawn_coordinates[i][0], self.spawn_coordinates[i][1], self.sprite_goomba[0],
                    self.sprite_goomba[1], self.sprite_goomba[2], self.sprite_goomba[3],
                    self.sprite_goomba[4],colkey=12)
                
                elif self.type_enemies_spawned_list[i]=="koopa":
                    pyxel.blt(self.spawn_coordinates[i][0], self.spawn_coordinates[i][1]-8, self.sprite_koopa[0],
                    self.sprite_koopa[1], self.sprite_koopa[2], self.sprite_koopa[3],
                    self.sprite_koopa[4],colkey=0)
            """
            else:
                self.ennemies_on_screen+=1
            
            else:
                del self.spawn_coordinates[i] 
                del self.enemies_spawned_list[i]"""