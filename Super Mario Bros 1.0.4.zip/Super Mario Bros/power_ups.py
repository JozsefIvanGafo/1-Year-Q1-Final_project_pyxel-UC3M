"""
Super mario bros game
description:
Here the program will execute the power ups.
@Author: József Iván Gafo and Marcos González
@since 11/14/2021
@Version 0.0.1
"""
import pyxel
import random
import pyxel
from Objects import Objects
class PowerUps:
    def __init__(self):
        self.sprite_mushroom = (0,0,32,16,16)
        self.coordinates_list_mushroom=[]
    def contact(self,hud,coordinates):
        random_number = random.randint(1,2)
        #we increase the coin counter by 1
        if random_number==1:
            hud.coins_counter()
            print("coin earned")
        else:
            #we take the coordinates to spawn  a mushroom
            self.coordinates_list_mushroom.append(coordinates)
    def print_mushrooms(self):
        for i in range(len(self.coordinates_list_mushroom)):
            pyxel.blt(self.coordinates_list_mushroom[i][0], self.coordinates_list_mushroom[i][1]-16, self.sprite_mushroom[0],
            self.sprite_mushroom[1], self.sprite_mushroom[2], self.sprite_mushroom[3],
            self.sprite_mushroom[4],colkey=0)
